
public class Menu 
{
	public Menu ()
	{
		
	}
	
	public void menu()
	{
		
		System.out.println ("Vortex Bank");
		System.out.println ("1. Nova Conta");
		System.out.println ("2. Depósito");
		System.out.println ("3. Emprestimo");
		System.out.println ("4. Levantamento");
		System.out.println ("5. Transferência");
		System.out.println ("6. Visualizar Dados");
		System.out.println ("7. Sair");
	}

}
