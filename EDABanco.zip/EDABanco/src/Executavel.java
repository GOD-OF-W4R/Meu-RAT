
public class Executavel 
{

	public static void main(String[] args) 
	{
		Menu m = new Menu();
	}

}
