
public class Cliente extends Conta 
{
	private String nuit, nuib, titular, nomePai, nomeMae, dataNascimento, numeroBI, profissao, estadoCivil, morada, numeroTelefone, email, genero;
	public Cliente (String numeroConta, String nIB, String nUIB, float saldo, String titular,String nomePai,String nomeMae,
			String dataNascimento,String numeroBI,String profissao,String estadoCivil,String morada,String numeroTelefone,String email,String genero, String nuit, String nuib)
	{
		super (numeroConta, nIB, nUIB, saldo);
			this.titular= titular;
			this.nomePai=nomePai;
			this.nomeMae=nomeMae;
			this.dataNascimento= dataNascimento;
			this.numeroBI= numeroBI;
			this.profissao= profissao;
			this.estadoCivil= estadoCivil;
			this.morada= morada;
			this.numeroTelefone= numeroTelefone;
			this.email= email;
			this.genero = genero; 
			this.nuit= nuit;
			this.nuib= nuib;
	}
	

	public Cliente() { this ("", "", "", 0, "", "","", "", "","","","","","","","","");}
		// TODO Auto-generated constructor stub


	public String getNuit() {
		return nuit;
	}


	public void setNuit(String nuit) {
		this.nuit = nuit;
	}


	public String getNuib() {
		return nuib;
	}


	public void setNuib(String nuib) {
		this.nuib = nuib;
	}


	public String getTitular() {
		return titular;
	}


	public void setTitular(String titular) {
		this.titular = titular;
	}


	public String getNomePai() {
		return nomePai;
	}


	public void setNomePai(String nomePai) {
		this.nomePai = nomePai;
	}


	public String getNomeMae() {
		return nomeMae;
	}


	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}


	public String getDataNascimento() {
		return dataNascimento;
	}


	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}


	public String getNumeroBI() {
		return numeroBI;
	}


	public void setNumeroBI(String numeroBI) {
		this.numeroBI = numeroBI;
	}


	public String getProfissao() {
		return profissao;
	}


	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}


	public String getEstadoCivil() {
		return estadoCivil;
	}


	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = estadoCivil;
	}


	public String getMorada() {
		return morada;
	}


	public void setMorada(String morada) {
		this.morada = morada;
	}


	public String getNumeroTelefone() {
		return numeroTelefone;
	}


	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	@Override
	public String toString() {
		return "\nCliente \nNuit: " + nuit + "\nNuib=" + nuib + ", Titular=" + titular + "\nNome Pai: " + nomePai
				+ "\nNome Mae: " + nomeMae + "\nData Nascimento=" + dataNascimento + "\nNumero BI: " + numeroBI
				+ "\nProfissao: " + profissao + "\nEstadoCivil:" + estadoCivil + "\nMorada: " + morada
				+ "Numero Telefone: " + numeroTelefone + "\nEmail: " + email + "\nGenero: " + genero;
	}
	
	
	
}
