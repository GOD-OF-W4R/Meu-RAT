import java.io.*;
public class Validacoes 
{
	private BufferedReader b;
	Validacoes ()
	{
		b = new BufferedReader (new InputStreamReader (System.in));
	}
	
	public String validString (String a, String c, String msg)
	{
		String n="";
		
		do
		{
			System.out.println (msg);
			try
			{
				n= b.readLine();
			}catch (NumberFormatException N) {System.out.println (N.getMessage());}
			catch (IOException i) {System.out.println (i.getMessage());}
			if (!n.equalsIgnoreCase(a) && !n.equalsIgnoreCase(c))
				System.out.println ("Tipo de Conta Inexistente! Tente novamente.");
		}while (!n.equalsIgnoreCase(a) && !n.equalsIgnoreCase(c));
		return n;
		
	}

	



}
