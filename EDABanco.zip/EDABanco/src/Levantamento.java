
public class Levantamento extends Conta
{
	public Levantamento ()
	{
		
	}

}
