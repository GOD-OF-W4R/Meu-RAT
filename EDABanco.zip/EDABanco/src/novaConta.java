import java.text.*;
import java.io.*;
public class novaConta
{
	private String tipoConta, numeroBI, dataNascimento, estadoCivil, bairroCasaQuarteir, profissao, genero, nomeDoPai, nomeDaMae;
	private int numeroTelefone;
	private DecimalFormat m;
	private Validacoes v;
	public static int contNovaConta =0;
	
	
	public novaConta ()
	{
		v = new Validacoes ();
		tipoConta =  v.validString("Poupanca","Corrente","Introduza o Tipo de Conta (Corrente/Poupança): ");
		
	}
	
	public String getNumeroBI() {
		return numeroBI;
	}

	public void setNumeroBI(String numeroBI) {
		this.numeroBI = numeroBI;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public String getBairroCasaQuarteir() {
		return bairroCasaQuarteir;
	}

	public void setBairroCasaQuarteir(String bairroCasaQuarteir) {
		this.bairroCasaQuarteir = bairroCasaQuarteir;
	}

	public String getProfissao() {
		return profissao;
	}

	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getNomeDoPai() {
		return nomeDoPai;
	}

	public void setNomeDoPai(String nomeDoPai) {
		this.nomeDoPai = nomeDoPai;
	}

	public String getNomeDaMae() {
		return nomeDaMae;
	}

	public void setNomeDaMae(String nomeDaMae) {
		this.nomeDaMae = nomeDaMae;
	}


	public int getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(int numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}



	

}
