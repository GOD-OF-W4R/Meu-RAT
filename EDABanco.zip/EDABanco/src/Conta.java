import java.text.DecimalFormat;

public class Conta 
{
	
	protected String nIB, nUIB, numeroConta;
	protected float saldo;
	private DecimalFormat m;
	public Conta (String numeroConta, String nIB, String nUIB, float saldo )
	{
		this.numeroConta=numeroConta;
		this.nIB = nIB;
		this.nUIB = nUIB;
		this.saldo=saldo;
		m= new DecimalFormat ("###,###.00 MTn");
	}
	
	
	public Conta () {this ("","","",0);}
	
	public String getnIB() {
		return nIB;
	}
	public void setnIB(String nIB) {
		this.nIB = nIB;
	}
	public String getnUIB() {
		return nUIB;
	}
	public void setnUIB(String nUIB) {
		this.nUIB = nUIB;
	}
	public float getSaldoAC() {
		return saldo;
	}
	public void setSaldoAC(float saldoAC) {
		this.saldo = saldoAC;
	}


	@Override
	public String toString() {
		return " Dados da conta\nNúmero Conta: " + numeroConta +"\nNIB: " + nIB + "\nNUIB: " + nUIB +  "\nSaldo: " + saldo ;
	}


	
	

}
