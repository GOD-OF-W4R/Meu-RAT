
public class Deposito extends Conta
{
	private int valorDeposito;
	public Deposito (String numeroConta, String nIB, String nUIB, float saldo, int valor)
	{
		super (numeroConta, nIB, nUIB, saldo );
		valorDeposito=valor;
		
		
	}
	
	public Deposito () {this("", "","",0,0);}

	public int getValorDeposito() 
	{
		return valorDeposito;
	}

	public void setValorDeposito(int valorDeposito) 
	{
		this.valorDeposito = valorDeposito;
	}
	
	
	

}
