
public class ContaCorrente extends Conta
{
	private float chequeLimiteEspecial;
	public ContaCorrente ()
	{
		
	}
}
