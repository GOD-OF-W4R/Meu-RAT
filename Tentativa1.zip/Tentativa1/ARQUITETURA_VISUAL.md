# 🏗️ ESTRUTURA DO PROJETO MELHORADO - DIAGRAMA

## HIERARQUIA DE CLASSES

```
                          ┌─────────────────────┐
                          │   JPanel (Swing)    │
                          └──────────┬──────────┘
                                     │
                          ┌──────────▼──────────┐
                          │   PainelBase        │  ◄─── CLASSE BASE ABSTRATA
                          │  (Abstract)         │        (Template Method Pattern)
                          ├─────────────────────┤
                          │ # gestor            │
                          │ + construir()       │  ◄─── ABSTRATO
                          │ # criarHeader()     │
                          │ # criarAcoes()      │
                          │ # estilizarTabela() │
                          │ # criarScroll()     │
                          └──────────┬──────────┘
                                     │
          ┌──────────────────────────┼──────────────────────────┐
          │                          │                          │
    ┌─────▼──────┐          ┌────────▼────────┐       ┌─────────▼──────┐
    │PainelDash  │          │PainelEncomendas │       │PainelClientes  │
    │board       │          │                 │       │                │
    └────────────┘          └─────────────────┘       └────────────────┘
                                    │
          ┌─────────────────────────┼─────────────────────────┐
          │                         │                         │
    ┌─────▼──────────┐     ┌────────▼────────┐     ┌──────────▼────────┐
    │PainelMovimen   │     │PainelRelatorios │     │ JanelaPrincipal  │
    │tacoes          │     │                 │     │  (JFrame)        │
    └────────────────┘     └─────────────────┘     └──────────────────┘
```

---

## HIERARQUIA DE MODELOS

```
    ┌──────────────────────────────────────────────────┐
    │           INTERFACES & ENUMS                     │
    ├──────────────────────────────────────────────────┤
    │                                                  │
    │  ┌──────────────┐      ┌──────────────────┐    │
    │  │ IGestor      │      │StatusEncomenda   │    │
    │  │ (Interface)  │      │ {PENDENTE,       │    │
    │  │              │      │  ENTREGUE,       │    │
    │  │ + criar...() │      │  CANCELADA}      │    │
    │  │ + editar...()│      │ (Enum)           │    │
    │  │ + listar...()│      └──────────────────┘    │
    │  │ + salvar()   │                              │
    │  │ + carregar() │      ┌──────────────────┐    │
    │  └──────────────┘      │TipoMovimentacao  │    │
    │                        │ {ENTRADA, SAIDA} │    │
    │                        │ (Enum)           │    │
    │                        └──────────────────┘    │
    └──────────────────────────────────────────────────┘
                              │
                              │ implementa
                              ▼
    ┌──────────────────────────────────────────────────┐
    │          GestorEncomendas (IGestor)              │
    ├──────────────────────────────────────────────────┤
    │ - arvoreEncomendas: ArvoreBinaria<Encomenda>   │
    │ - arvoreClientes: ArvoreBinaria<Cliente>       │
    │ - historico: List<Movimentacao>                │
    │ + cadastrar/editar/excluir/buscar...()         │
    │ + registrarMovimentacao()                      │
    │ + getValorTotalStock()                         │
    │ + getTotalEncomendas/Clientes/Movimentacoes()  │
    │ + salvarDados() / carregarDados()              │
    └──────────────────────────────────────────────────┘
                              │
            ┌─────────────────┼─────────────────┐
            │                 │                 │
     ┌──────▼──────┐  ┌───────▼────────┐ ┌─────▼────────┐
     │ Encomenda   │  │ Cliente        │ │Movimentacao  │
     │ (modelo)    │  │ (modelo)       │ │ (modelo)     │
     ├─────────────┤  ├────────────────┤ ├──────────────┤
     │ - codigo    │  │ - id           │ │ - id         │
     │ - descr.    │  │ - nome         │ │ - encomenda  │
     │ - prazo     │  │ - contacto     │ │ - tipo       │
     │ - massa     │  │ - endereco     │ │ - quantidade │
     │ - volume    │  │ - email        │ │ - data       │
     │ - stock     │  │                │ │ - obs        │
     │ - status    │  │ + equals()     │ │              │
     │ + calcular  │  │ + hashCode()   │ │ + equals()   │
     │   TaxaEnv()│  │ + compareTo()  │ │ + hashCode()  │
     │ + precisaR  │  │               │ │ + toString()  │
     │   epor()    │  │               │ │              │
     │ + compareTo│  │ (Comparable)   │ │              │
     │()         │  │               │ │              │
     │(Comparable)│  │               │ │              │
     └────────────┘  └────────────────┘ └──────────────┘
            │                │                 │
            │                │                 │
            └────────┬────────┴─────────┬──────┘
                     │                  │
                     │ (Serializable)   │
                     │                  │
            ┌────────▼──────────────────▼────┐
            │  ArvoreBinaria<T>               │
            │  (Estrutura de Dados)           │
            ├─────────────────────────────────┤
            │ - raiz: NoArvore<T>             │
            │ - tamanho: int                  │
            │ + inserir(T, Comparator)        │
            │ + buscar(Predicate)             │
            │ + remover(Predicate, Comp)      │
            │ + emOrdem(): List<T>            │
            │ + filtrar(Predicate)            │
            │ + getTamanho()                  │
            │ + estaVazia()                   │
            └──────────────┬──────────────────┘
                           │
                    ┌──────▼──────────┐
                    │ NoArvore<T>     │
                    │ (private fields)│
                    ├─────────────────┤
                    │ - dado: T       │
                    │ - esquerda: ... │
                    │ - direita: ...  │
                    │ + getDado()     │
                    │ + getEsquerda() │
                    │ + getDireita()  │
                    │ + setters...()  │
                    └─────────────────┘
```

---

## FLUXO DE DADOS

```
┌─────────────────────────────────────────────────────────────┐
│               CAMADA DE APRESENTAÇÃO (UI)                   │
│  JanelaPrincipal [JFrame] ◄─── CardLayout (5 Painéis)      │
│        │                                                     │
│        ├─► PainelDashboard    (exibe métricas)             │
│        ├─► PainelEncomendas    (CRUD Encomendas)           │
│        ├─► PainelClientes      (CRUD Clientes)             │
│        ├─► PainelMovimentacoes (Registrar movimentos)      │
│        └─► PainelRelatorios    (Exibir relatórios)         │
│              (Todas estendem PainelBase)                    │
└─────────────────────┬──────────────────────────────────────┘
                      │
                      │ (utiliza)
                      ▼
┌─────────────────────────────────────────────────────────────┐
│          CAMADA DE LÓGICA DE NEGÓCIO                        │
│         GestorEncomendas (implementa IGestor)               │
│  Coordena todas as operações do sistema                     │
└─────────────────────┬──────────────────────────────────────┘
                      │
                      │ (gerencia)
         ┌────────────┼────────────┐
         │            │            │
         ▼            ▼            ▼
    ┌─────────┐ ┌──────────┐ ┌────────────┐
    │ Árvore  │ │ Árvore   │ │ Lista de   │
    │Encomend│ │ Clientes │ │Movimentação│
    └─────────┘ └──────────┘ └────────────┘
         │            │            │
         └────────────┼────────────┘
                      │
                      │ (serializa)
                      ▼
         ┌──────────────────────────┐
         │  arquivo: dados.ser      │
         │  (Persistência)          │
         └──────────────────────────┘
```

---

## PADRÕES DE DESIGN UTILIZADOS

```
1. TEMPLATE METHOD PATTERN
   ┌──────────────────────────────────┐
   │ PainelBase (abstrato)            │
   │ + construir() ◄─── ABSTRATO      │
   └────────────┬─────────────────────┘
                │
                └─► Implementado em cada painel específico


2. STRATEGY PATTERN
   ┌──────────────┐
   │   IGestor    │ ◄─── Interface (contrato)
   │ (Interface)  │
   └────────────┬─┘
                │
         ┌──────┴──────────┐
         │                 │
    Implementação:    Futuras alternativas:
    GestorEncomendas  GestorEncomendasBD
                      GestorEncomendasAPI


3. FACADE PATTERN
   ┌────────────────────────┐
   │  Componentes (Facade)  │ ◄─── Simplifica criação de UI
   │  + BotaoVerde          │
   │  + CampoTexto          │
   │  + labelTitulo         │
   └────────────────────────┘


4. ENUMERATION PATTERN
   ┌──────────────────┐
   │StatusEncomenda   │ ◄─── Substitui Strings
   │(PENDENTE,        │      Typesafe
   │ ENTREGUE,        │      Melhor performance
   │ CANCELADA)       │
   └──────────────────┘
```

---

## APLICAÇÃO DE CONCEITOS OOP

```
┌─────────────────────────────────────────────────────────┐
│ 1. ENCAPSULAMENTO                                       │
│    ✅ Private: dados em modelos e estruturas           │
│    ✅ Getters/Setters: acesso controlado                │
│    ✅ Validação em setters: proteção de dados           │
├─────────────────────────────────────────────────────────┤
│ 2. HERANÇA                                              │
│    ✅ PainelBase ◄── 5 Painéis específicos             │
│    ✅ EncomendaTest ◄── Encomenda (compatibilidade)    │
│    ✅ Template Method em PainelBase                     │
├─────────────────────────────────────────────────────────┤
│ 3. POLIMORFISMO                                         │
│    ✅ Enum StatusEncomenda (tipos polimórficos)        │
│    ✅ Enum TipoMovimentacao                            │
│    ✅ Interface IGestor (múltiplas implementações)      │
│    ✅ Método construir() sobrescrito em cada painel     │
├─────────────────────────────────────────────────────────┤
│ 4. ABSTRAÇÃO                                            │
│    ✅ PainelBase abstrata (não instanciável)           │
│    ✅ Método construir() abstrato                      │
│    ✅ Interface IGestor (contrato)                     │
│    ✅ Enums (abstração de tipos)                       │
├─────────────────────────────────────────────────────────┤
│ 5. INTERFACES & CONTRATOS                              │
│    ✅ IGestor: define responsabilidades               │
│    ✅ Serializable: persistência                      │
│    ✅ Comparable: ordenação natural                    │
└─────────────────────────────────────────────────────────┘
```

---

## CHECKLIST FINAL

```
ESTRUTURA OOP
  ✅ Encapsulamento (private/public correto)
  ✅ Herança (PainelBase e extensões)
  ✅ Polimorfismo (Enums, Interfaces, Methods)
  ✅ Abstração (Classes abstratas, Interfaces)
  ✅ Composição (GestorEncomendas usa ArvoreBinaria)

DESIGN
  ✅ Separação de responsabilidades
  ✅ Coesão alta em classes
  ✅ Baixo acoplamento
  ✅ Padrões de design (Template Method, Strategy, Facade)

QUALIDADE
  ✅ Validação de dados
  ✅ Tratamento de exceções
  ✅ JavaDoc documentação
  ✅ Naming conventions corretas
  ✅ Constantes centralizadas

REQUISITOS DO PROJETO
  ✅ Programação abstrata (AbstractClass, Interface)
  ✅ Herança (PainelBase, Encomenda)
  ✅ Orienta a Objetos (todos os conceitos)
  ✅ Árvores binárias (ArvoreBinaria<T>)
  ✅ Polimorfismo (Enums, Methods overriding)
```

---

*Diagrama atualizado em: 28 de Maio de 2026*
