package c;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class PainelClientes extends JPanel {

    private GestorEncomendas gestor;
    private JTable tabela;
    private DefaultTableModel modeloTabela;

    public PainelClientes(GestorEncomendas gestor) {
        this.gestor = gestor;
        setBackground(Tema.FUNDO_PRINCIPAL);
        setLayout(new BorderLayout());
        construir();
        carregarTabela();
    }

    private void construir() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        header.add(Componentes.labelTitulo("👥 Clientes"), BorderLayout.WEST);

        JButton btnNovo = new Componentes.BotaoVerde("+ Novo Cliente");
        btnNovo.addActionListener(e -> abrirDialogoCliente());
        JButton btnRemover = new Componentes.BotaoPerigo("Remover Cliente");
        btnRemover.addActionListener(e -> removerClienteSelecionado());

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoes.setOpaque(false);
        acoes.add(btnRemover);
        acoes.add(btnNovo);
        header.add(acoes, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);
        
        
        String[] colunas = {"ID", "Nome", "Contacto", "Endereço", "Condições Pagamento", "Email"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modeloTabela);
        estilizarTabela();
        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
        add(scroll, BorderLayout.CENTER);
    }

    private void estilizarTabela() {
        tabela.setBackground(Tema.FUNDO_CARD);
        tabela.setForeground(Tema.TEXTO_PRINCIPAL);
        tabela.setFont(Tema.fonteCorpo(13));
        tabela.setRowHeight(30);
    }

    private void carregarTabela() {
        modeloTabela.setRowCount(0);
        List<Cliente> lista = gestor.listarClientes();
        for (Cliente c : lista) {
            modeloTabela.addRow(new Object[]{
                c.getId(), c.getNome(), c.getContacto(),
                c.getEndereco(), c.getCondicoesPagamento(), c.getEmail()
            });
        }
    }

    private void abrirDialogoCliente() {
        String idGerado = gestor.gerarIdCliente(); // gera automaticamente

        JTextField nomeField = new JTextField();
        JTextField contactoField = new JTextField();
        JTextField enderecoField = new JTextField();
        JTextField condPagField = new JTextField();
        JTextField emailField = new JTextField();

        Object[] campos = {
            "ID: " + idGerado,
            "Nome:", nomeField,
            "Contacto:", contactoField,
            "Endereço:", enderecoField,
            "Condições de Pagamento:", condPagField,
            "Email:", emailField
        };

        int opcao = JOptionPane.showConfirmDialog(this, campos, "Novo Cliente", JOptionPane.OK_CANCEL_OPTION);
        if (opcao == JOptionPane.OK_OPTION) {
            try {
                Cliente novo = new Cliente(
                    idGerado,
                    nomeField.getText(),
                    contactoField.getText(),
                    enderecoField.getText(),
                    condPagField.getText(),
                    emailField.getText()
                );

                validarCliente(novo);
                gestor.cadastrarCliente(novo);
                carregarTabela();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage(), "Validação", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void validarCliente(Cliente c) {
        if (c.getNome() == null || c.getNome().isEmpty())
            throw new IllegalArgumentException("Nome é obrigatório.");
        if (c.getContacto() == null || c.getContacto().isEmpty())
            throw new IllegalArgumentException("Contacto é obrigatório.");
        if (c.getEmail() == null || !c.getEmail().matches("^[\\w.-]+@[\\w.-]+\\.[a-z]{2,}$"))
            throw new IllegalArgumentException("Email inválido.");
    }
    
   
    private void removerClienteSelecionado() {
        int linha = tabela.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um cliente primeiro.");
            return;
        }
        String id = (String) modeloTabela.getValueAt(linha, 0);
        gestor.removerCliente(id);
        carregarTabela();
    }
    
    
}
