package c;

import java.io.*;

/**
 * Classe Encomenda - Representa uma encomenda no sistema Fikissa
 * 
 * Propriedades:
 * - Identificada por código único
 * - Rastreia massa, volume, prazos de entrega
 * - Controla níveis de stock com alertas
 * - Vinculada a um cliente
 * 
 * Herança: Implementa Serializable para persistência
 * Encapsulamento: Todos os campos private com getters/setters
 * 
 * @author Sistema Fikissa
 * @version 2.0
 */
public class Encomenda implements Serializable, Comparable<Encomenda> {
    private static final long serialVersionUID = 1L;

    // Identificação
    private String codigo;                    // Único, ex: ENC001
    private String descricao;                 // Breve descrição do conteúdo

    // Logística
    private int prazoEntrega;                 // Em dias (1, 2, etc)
    private double massa;                     // Em kg
    private double volume;                    // Em m³
    private String localOrigem;               // Ponto de partida
    private String localDestino;              // Ponto de entrega
    private String contactoRemetente;         // Telefone/Email do remetente
    private String enderecoRemetente;         // Endereço do remetente
    private String contactoDestinatario;      // Telefone/Email do destinatário
    private String enderecoDestinatario;      // Endereço do destinatário

    // Inventário
    private int quantidadeStock;              // Nível atual em stock
    private int quantidadeMinima;             // Limite mínimo para alerta

    // Status
    private StatusEncomenda status;           // PENDENTE, ENTREGUE, CANCELADA
    private Cliente cliente;                  // Cliente associado

    /**
     * Construtor completo da Encomenda
     */
    public Encomenda(String codigo, String descricao, int prazoEntrega, double massa, double volume,
                     String localOrigem, String localDestino, String contactoRemetente,
                     String enderecoRemetente, String contactoDestinatario, String enderecoDestinatario) {
        validarDados(codigo, descricao, prazoEntrega, massa, volume);
        
        this.codigo = codigo;
        this.descricao = descricao;
        this.prazoEntrega = prazoEntrega;
        this.massa = massa;
        this.volume = volume;
        this.localOrigem = localOrigem;
        this.localDestino = localDestino;
        this.contactoRemetente = contactoRemetente;
        this.enderecoRemetente = enderecoRemetente;
        this.contactoDestinatario = contactoDestinatario;
        this.enderecoDestinatario = enderecoDestinatario;
        this.quantidadeStock = 0;
        this.quantidadeMinima = 5;             // Valor padrão
        this.status = StatusEncomenda.PENDENTE;
        this.cliente = null;
    }

    /**
     * Valida os dados críticos da encomenda
     */
    private void validarDados(String codigo, String descricao, int prazo, double massa, double volume) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("Código da encomenda não pode estar vazio.");
        }
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("Descrição não pode estar vazia.");
        }
        if (prazo <= 0) {
            throw new IllegalArgumentException("Prazo de entrega deve ser maior que 0.");
        }
        if (massa <= 0) {
            throw new IllegalArgumentException("Massa deve ser maior que 0.");
        }
        if (volume <= 0) {
            throw new IllegalArgumentException("Volume deve ser maior que 0.");
        }
    }

    /**
     * Calcula a taxa de envio com base em massa e volume
     * Taxa: 2€ por kg + 100€ por m³
     * 
     * @return Taxa de envio calculada
     */
    public double calcularTaxaEnvio() {
        return (this.massa * 2) + (this.volume * 100);
    }

    /**
     * Verifica se a encomenda necessita reposição
     * 
     * @return true se stock <= quantidade mínima
     */
    public boolean precisaRepor() {
        return quantidadeStock <= quantidadeMinima;
    }

    /**
     * Implementação de Comparable para ordenação por código
     */
    @Override
    public int compareTo(Encomenda outra) {
        return this.codigo.compareTo(outra.codigo);
    }

    // ========== GETTERS E SETTERS ==========

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("Código não pode estar vazio.");
        }
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("Descrição não pode estar vazia.");
        }
        this.descricao = descricao;
    }

    public int getPrazoEntrega() {
        return prazoEntrega;
    }

    public void setPrazoEntrega(int prazoEntrega) {
        if (prazoEntrega <= 0) {
            throw new IllegalArgumentException("Prazo deve ser maior que 0.");
        }
        this.prazoEntrega = prazoEntrega;
    }

    public double getMassa() {
        return massa;
    }

    public void setMassa(double massa) {
        if (massa <= 0) {
            throw new IllegalArgumentException("Massa deve ser maior que 0.");
        }
        this.massa = massa;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        if (volume <= 0) {
            throw new IllegalArgumentException("Volume deve ser maior que 0.");
        }
        this.volume = volume;
    }

    public String getLocalOrigem() {
        return localOrigem;
    }

    public void setLocalOrigem(String localOrigem) {
        if (localOrigem == null || localOrigem.trim().isEmpty()) {
            throw new IllegalArgumentException("Local de origem não pode estar vazio.");
        }
        this.localOrigem = localOrigem;
    }

    public String getLocalDestino() {
        return localDestino;
    }

    public void setLocalDestino(String localDestino) {
        if (localDestino == null || localDestino.trim().isEmpty()) {
            throw new IllegalArgumentException("Local de destino não pode estar vazio.");
        }
        this.localDestino = localDestino;
    }

    public String getContactoRemetente() {
        return contactoRemetente;
    }

    public void setContactoRemetente(String contactoRemetente) {
        if (contactoRemetente == null || contactoRemetente.trim().isEmpty()) {
            throw new IllegalArgumentException("Contacto do remetente não pode estar vazio.");
        }
        this.contactoRemetente = contactoRemetente;
    }

    public String getEnderecoRemetente() {
        return enderecoRemetente;
    }

    public void setEnderecoRemetente(String enderecoRemetente) {
        if (enderecoRemetente == null || enderecoRemetente.trim().isEmpty()) {
            throw new IllegalArgumentException("Endereço do remetente não pode estar vazio.");
        }
        this.enderecoRemetente = enderecoRemetente;
    }

    public String getContactoDestinatario() {
        return contactoDestinatario;
    }

    public void setContactoDestinatario(String contactoDestinatario) {
        if (contactoDestinatario == null || contactoDestinatario.trim().isEmpty()) {
            throw new IllegalArgumentException("Contacto do destinatário não pode estar vazio.");
        }
        this.contactoDestinatario = contactoDestinatario;
    }

    public String getEnderecoDestinatario() {
        return enderecoDestinatario;
    }

    public void setEnderecoDestinatario(String enderecoDestinatario) {
        if (enderecoDestinatario == null || enderecoDestinatario.trim().isEmpty()) {
            throw new IllegalArgumentException("Endereço do destinatário não pode estar vazio.");
        }
        this.enderecoDestinatario = enderecoDestinatario;
    }

    public int getQuantidadeStock() {
        return quantidadeStock;
    }

    public void setQuantidadeStock(int quantidadeStock) {
        if (quantidadeStock < 0) {
            throw new IllegalArgumentException("Quantidade não pode ser negativa.");
        }
        this.quantidadeStock = quantidadeStock;
    }

    public int getQuantidadeMinima() {
        return quantidadeMinima;
    }

    public void setQuantidadeMinima(int quantidadeMinima) {
        if (quantidadeMinima < 0) {
            throw new IllegalArgumentException("Quantidade mínima não pode ser negativa.");
        }
        this.quantidadeMinima = quantidadeMinima;
    }

    public StatusEncomenda getStatus() {
        return status;
    }

    public void setStatus(StatusEncomenda status) {
        if (status == null) {
            throw new IllegalArgumentException("Status não pode ser nulo.");
        }
        this.status = status;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public String toString() {
        return codigo + " - " + descricao + " (Stock: " + quantidadeStock + ", Status: " + status.getDescricao() + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || !(obj instanceof Encomenda)) return false;
        Encomenda outra = (Encomenda) obj;
        return this.codigo.equals(outra.codigo);
    }

    @Override
    public int hashCode() {
        return codigo.hashCode();
    }
}
