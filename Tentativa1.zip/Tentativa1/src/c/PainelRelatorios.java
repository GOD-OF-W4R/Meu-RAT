package c;
import java.text.DecimalFormat;
import javax.swing.*;
import java.awt.*;

public class PainelRelatorios extends JPanel {

    private GestorEncomendas gestor;

    public PainelRelatorios(GestorEncomendas gestor) {
        this.gestor = gestor;
        setBackground(Tema.FUNDO_PRINCIPAL);
        setLayout(new BorderLayout());
        construir();
    }

    private void construir() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        header.add(Componentes.labelTitulo("📈 Relatórios e Análises"), BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        JPanel corpo = new JPanel(new GridLayout(2, 2, 15, 15));
        corpo.setOpaque(false);
        corpo.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        corpo.add(criarCardRelatorio("📦 Encomendas com Stock Baixo",
                "Lista de produtos que precisam reposição.", () -> {
            JOptionPane.showMessageDialog(this, "Relatório de stock baixo:\n" + gestor.getEncomendasStockBaixo().size() + " encomendas." );
        }));

        corpo.add(criarCardRelatorio("💰 Valor Total do Stock",
                "Valor estimado baseado na taxa de envio.", () -> {
            JOptionPane.showMessageDialog(this, "Valor total do stock: " + gestor.getValorTotalStock()+"");
        }));

        corpo.add(criarCardRelatorio("📊 Total de Movimentações",
                "Número total de entradas e saídas.", () -> {
            JOptionPane.showMessageDialog(this, "Total de movimentações: " + gestor.getHistorico().size());
        }));

        corpo.add(criarCardRelatorio("👥 Clientes Registados",
                "Quantidade de clientes no sistema.", () -> {
            JOptionPane.showMessageDialog(this, "Clientes: " + gestor.listarClientes().size());
        }));

        add(corpo, BorderLayout.CENTER);
    }

    private JPanel criarCardRelatorio(String titulo, String desc, Runnable acao) {
        Componentes.PainelCard card = new Componentes.PainelCard();
        card.setLayout(new BorderLayout(0, 10));
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lTit = new JLabel(titulo);
        lTit.setFont(Tema.fonteSubtitulo(14));
        lTit.setForeground(Tema.DOURADO);

        JLabel lDesc = new JLabel("<html><p style='width:200px;color:#aaa;font-size:11px;'>" + desc + "</p></html>");

        Componentes.BotaoVerde btn = new Componentes.BotaoVerde("Gerar");
        btn.addActionListener(e -> acao.run());
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setOpaque(false);
        btnPanel.add(btn);

        card.add(lTit, BorderLayout.NORTH);
        card.add(lDesc, BorderLayout.CENTER);
        card.add(btnPanel, BorderLayout.SOUTH);
        return card;
    }
}