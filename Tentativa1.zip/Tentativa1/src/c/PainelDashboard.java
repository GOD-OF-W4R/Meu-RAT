package c;

import javax.swing.*;
import java.awt.*;

/**
 * Painel Dashboard - Exibe métricas principais do sistema
 * Estende PainelBase para herança
 */
public class PainelDashboard extends PainelBase {
    private JLabel lblEncomendas;
    private JLabel lblClientes;
    private JLabel lblMovimentacoes;
    private JLabel lblValorStock;

    public PainelDashboard(GestorEncomendas gestor) {
        super(gestor);
        atualizar();
    }

    @Override
    protected void construir() {
        JPanel header = criarHeaderPadrao("🚛 Bem-vindo à Fikissa");
        add(header, BorderLayout.NORTH);

        JPanel corpo = new JPanel(new GridLayout(2, 2, 18, 18));
        corpo.setOpaque(false);
        corpo.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        lblEncomendas = criarIndicador("0", "Encomendas ativas no sistema.");
        lblClientes = criarIndicador("0", "Clientes registados.");
        lblMovimentacoes = criarIndicador("0", "Movimentações registradas.");
        lblValorStock = criarIndicador("0.00", "Valor estimado de stock.");

        corpo.add(criarCartao("Encomendas Ativas", lblEncomendas));
        corpo.add(criarCartao("Clientes", lblClientes));
        corpo.add(criarCartao("Movimentações", lblMovimentacoes));
        corpo.add(criarCartao("Valor do Stock", lblValorStock));

        add(corpo, BorderLayout.CENTER);
    }

    private JPanel criarCartao(String titulo, JLabel valorLabel) {
        Componentes.PainelCard card = new Componentes.PainelCard();
        card.setLayout(new BorderLayout(0, 10));
        card.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel lTitulo = new JLabel(titulo);
        lTitulo.setFont(Tema.fonteSubtitulo(14));
        lTitulo.setForeground(Tema.DOURADO);

        valorLabel.setFont(Tema.fonteTitulo(28));
        valorLabel.setForeground(Tema.TEXTO_PRINCIPAL);

        card.add(lTitulo, BorderLayout.NORTH);
        card.add(valorLabel, BorderLayout.CENTER);
        return card;
    }

    private JLabel criarIndicador(String valor, String tooltip) {
        JLabel label = new JLabel(valor, SwingConstants.LEFT);
        label.setFont(Tema.fonteTitulo(28));
        label.setForeground(Tema.TEXTO_PRINCIPAL);
        label.setToolTipText(tooltip);
        return label;
    }

    public void atualizar() {
        lblEncomendas.setText(String.valueOf(gestor.getTotalEncomendasActivas()));
        lblClientes.setText(String.valueOf(gestor.getTotalClientes()));
        lblMovimentacoes.setText(String.valueOf(gestor.getTotalMovimentacoes()));
        lblValorStock.setText(String.format("%.2f", gestor.getValorTotalStock()));
    }
}
