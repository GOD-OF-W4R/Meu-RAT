package c;

/**
 * Classe Constantes - Centraliza todas as constantes do sistema
 * Facilita manutenção e configuração global
 * 
 * @author Sistema Fikissa
 */
public class Constantes {
    // ========== ARQUIVO DE DADOS ==========
    public static final String ARQUIVO_DADOS = "dados.ser";
    
    // ========== PREFIXOS DE ID ==========
    public static final String PREFIXO_CLIENTE = "CLI";
    public static final String PREFIXO_ENCOMENDA = "ENC";
    public static final String PREFIXO_MOVIMENTACAO = "MOV";
    
    // ========== FORMATO DE IDS ==========
    public static final String FORMATO_ID = "%03d";
    
    // ========== VALORES PADRÃO ==========
    public static final int QUANTIDADE_MINIMA_PADRAO = 5;
    public static final double TAXA_BASE_KG = 2.0;
    public static final double TAXA_BASE_M3 = 100.0;
    
    // ========== MENSAGENS ==========
    public static final String MSG_ENCOMENDA_DUPLICADA = "Já existe encomenda com este código.";
    public static final String MSG_CLIENTE_DUPLICADO = "Cliente com este ID já existe.";
    public static final String MSG_ENCOMENDA_NAO_ENCONTRADA = "Encomenda não encontrada.";
    public static final String MSG_CLIENTE_NAO_ENCONTRADO = "Cliente não encontrado.";
    public static final String MSG_STOCK_INSUFICIENTE = "Stock insuficiente.";
    public static final String TITULO_ALERTA_STOCK = "Gestor Fikissa - Alerta de Stock";
    
    // Construtor privado para evitar instanciação
    private Constantes() {
        throw new AssertionError("Classe utilitária não deve ser instanciada.");
    }
}
