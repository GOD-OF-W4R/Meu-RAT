package c;

import javax.swing.*;
import java.awt.*;

/**
 * Classe Abstrata PainelBase - Classe pai para todos os painéis do sistema
 * 
 * Utiliza padrão Template Method para definir estrutura comum:
 * - Construção visual
 * - Estilo consistente
 * - Métodos abstratos para implementação específica
 * 
 * Promove:
 * - Herança: Subclasses estendem PainelBase
 * - Polimorfismo: Método construir() é sobrescrito em cada painel
 * - Encapsulamento: Gestor protected para subclasses
 * 
 * @author Sistema Fikissa
 * @version 2.0
 */
public abstract class PainelBase extends JPanel {
    protected GestorEncomendas gestor;

    /**
     * Construtor base para todos os painéis
     */
    public PainelBase(GestorEncomendas gestor) {
        this.gestor = gestor;
        setBackground(Tema.FUNDO_PRINCIPAL);
        setLayout(new BorderLayout());
        construir();
    }

    /**
     * Método abstrato - Cada painel implementa sua própria construção
     * Método Template - Define estrutura, subclasses implementam detalhes
     */
    protected abstract void construir();

    /**
     * Cria um header padrão com título
     */
    protected JPanel criarHeaderPadrao(String titulo) {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        header.add(Componentes.labelTitulo(titulo), BorderLayout.WEST);
        return header;
    }

    /**
     * Cria um painel de ações padrão (botões)
     */
    protected JPanel criarPainelAcoes(JButton... botoes) {
        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoes.setOpaque(false);
        for (JButton btn : botoes) {
            acoes.add(btn);
        }
        return acoes;
    }

    /**
     * Estiliza uma tabela com o tema do sistema
     */
    protected void estilizarTabela(JTable tabela) {
        tabela.setBackground(Tema.FUNDO_CARD);
        tabela.setForeground(Tema.TEXTO_PRINCIPAL);
        tabela.setFont(Tema.fonteCorpo(13));
        tabela.setRowHeight(30);
    }

    /**
     * Cria um scroll pane estilizado
     */
    protected JScrollPane criarScrollEstilizado(JComponent componente) {
        JScrollPane scroll = new JScrollPane(componente);
        scroll.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
        return scroll;
    }
}
