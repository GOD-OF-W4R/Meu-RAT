package c;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JanelaPrincipal extends JFrame {

    private GestorEncomendas gestor;
    private JPanel painelConteudo;
    private CardLayout cardLayout;
    private JPanel[] botoesNav;
    private int abaSelecionada = 0;

    public JanelaPrincipal() {
        gestor = new GestorEncomendas();
        configurarJanela();
        construirUI();
        mostrarAba(0);
        mostrarTelaInicial();
    }

    private void configurarJanela() {
        setTitle("Fikissa - Sistema de Gestão de Encomendas");
        setSize(1200, 750);
        setMinimumSize(new Dimension(960, 600));
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            
            public void windowClosing(WindowEvent e) {
                gestor.salvarDados(); // salva antes de fechar
                System.exit(0);
            }
        });

        setVisible(true);
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
    }

    private void construirUI() {
        JPanel raiz = new JPanel(new BorderLayout());
        raiz.setBackground(Tema.FUNDO_PRINCIPAL);

        JPanel sidebar = criarSidebar();
        raiz.add(sidebar, BorderLayout.WEST);

        cardLayout = new CardLayout();
        painelConteudo = new JPanel(cardLayout);
        painelConteudo.setBackground(Tema.FUNDO_PRINCIPAL);

        // Painéis – todos recebem o gestor
        painelConteudo.add(new PainelDashboard(gestor), "Pagina Inicial");
        painelConteudo.add(new PainelEncomendas(gestor), "encomendas");
        painelConteudo.add(new PainelClientes(gestor), "clientes");
        painelConteudo.add(new PainelMovimentacoes(gestor), "movimentacoes");
        painelConteudo.add(new PainelRelatorios(gestor), "relatorios");

        raiz.add(painelConteudo, BorderLayout.CENTER);
        setContentPane(raiz);
    }

    private void mostrarTelaInicial() {
        cardLayout.show(painelConteudo, "Pagina Inicial");
    }

    private JPanel criarSidebar() {
        JPanel sidebar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Tema.FUNDO_CARD);
                g2.fillRect(0, 0, getWidth(), getHeight());
                GradientPaint gp = new GradientPaint(0, 0, Tema.VERDE_CAMPO, getWidth(), 0, Tema.VERDE_ESCURO);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), 4);
                g2.dispose();
            }
        };
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setLayout(new BorderLayout());

        // Logo
        JPanel logoPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Tema.FUNDO_PRINCIPAL);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(Tema.VERDE_CAMPO);
                g2.fillOval(20, 18, 52, 52);
                g2.setColor(new Color(255,255,255,40));
                g2.fillOval(24, 20, 22, 22);
                g2.setFont(new Font("Georgia", Font.BOLD, 22));
                g2.setColor(Tema.TEXTO_PRINCIPAL);
                g2.drawString("Fikissa", 82, 38);
                g2.setFont(new Font("Georgia", Font.BOLD, 14));
                g2.setColor(Tema.VERDE_CAMPO);
                g2.drawString("Encomendas", 84, 56);
                g2.setFont(new Font("Fikissa", Font.PLAIN, 10));
                g2.setColor(Tema.TEXTO_SECUNDARIO);
                g2.drawString("Gestão de Stock", 82, 72);
                g2.dispose();
            }
        };
        logoPanel.setPreferredSize(new Dimension(220, 100));
        logoPanel.setOpaque(false);
        sidebar.add(logoPanel, BorderLayout.NORTH);

        // Navegação
        JPanel nav = new JPanel();
        nav.setOpaque(false);
        nav.setLayout(new BoxLayout(nav, BoxLayout.Y_AXIS));
        nav.setBorder(BorderFactory.createEmptyBorder(16, 0, 0, 0));

        String[][] itens = {
            {"📊", "Pagina Inicial", "Pagina Inicial"},
            {"📦", "Encomendas", "encomendas"},
            {"👥", "Clientes", "clientes"},
            {"🔄", "Movimentações", "movimentacoes"},
            {"📈", "Relatórios", "relatorios"}
        };

        botoesNav = new JPanel[itens.length];
        for (int i = 0; i < itens.length; i++) {
            botoesNav[i] = criarBotaoNav(itens[i][0], itens[i][1], itens[i][2], i);
            nav.add(botoesNav[i]);
            nav.add(Box.createVerticalStrut(2));
        }

        sidebar.add(nav, BorderLayout.CENTER);

        // Rodapé
        JPanel footer = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(Tema.FUNDO_PRINCIPAL);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setFont(new Font("Fikissa", Font.PLAIN, 10));
                g2.setColor(Tema.TEXTO_SECUNDARIO);
                g2.drawString("ISCTEM · AED I · 2026", 16, 20);
                g2.drawString("Trabalho de AED, Grupo3", 16, 34);
                g2.dispose();
            }
        };
        footer.setPreferredSize(new Dimension(220, 50));
        footer.setOpaque(false);
        sidebar.add(footer, BorderLayout.SOUTH);

        return sidebar;
    }

    private JPanel criarBotaoNav(String icone, String texto, String chave, int idx) {
        JPanel btn = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (abaSelecionada == idx) {
                    g2.setColor(Tema.FUNDO_PRINCIPAL);
                    g2.fillRoundRect(8, 0, getWidth() - 8, getHeight(), 10, 10);
                    g2.setColor(Tema.VERDE_CAMPO);
                    g2.fillRoundRect(0, 6, 4, getHeight() - 12, 4, 4);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setOpaque(false);
        btn.setPreferredSize(new Dimension(220, 46));
        btn.setMaximumSize(new Dimension(220, 46));
        btn.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 12));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel lIcone = new JLabel(icone);
        lIcone.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lIcone.setForeground(abaSelecionada == idx ? Tema.VERDE_CAMPO : Tema.TEXTO_SECUNDARIO);
        lIcone.setPreferredSize(new Dimension(30, 46));

        JLabel lTexto = new JLabel(texto);
        lTexto.setFont(Tema.fonteSubtitulo(13));
        lTexto.setForeground(abaSelecionada == idx ? Tema.TEXTO_PRINCIPAL : Tema.TEXTO_SECUNDARIO);

        btn.add(lIcone, BorderLayout.WEST);
        btn.add(lTexto, BorderLayout.CENTER);

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (abaSelecionada != idx) {
                    lIcone.setForeground(Tema.TEXTO_PRINCIPAL);
                    lTexto.setForeground(Tema.TEXTO_PRINCIPAL);
                }
            }
            public void mouseExited(MouseEvent e) {
                if (abaSelecionada != idx) {
                    lIcone.setForeground(Tema.TEXTO_SECUNDARIO);
                    lTexto.setForeground(Tema.TEXTO_SECUNDARIO);
                }
            }
            public void mouseClicked(MouseEvent e) {
                mostrarAba(idx);
                cardLayout.show(painelConteudo, chave);
            }
        });

        return btn;
    }

    private void mostrarAba(int idx) {
        abaSelecionada = idx;
        for (int i = 0; i < botoesNav.length; i++) {
            Component[] comps = botoesNav[i].getComponents();
            boolean ativo = (i == idx);
            if (comps.length >= 2) {
                ((JLabel) comps[0]).setForeground(ativo ? Tema.VERDE_CAMPO : Tema.TEXTO_SECUNDARIO);
                ((JLabel) comps[1]).setForeground(ativo ? Tema.TEXTO_PRINCIPAL : Tema.TEXTO_SECUNDARIO);
            }
            botoesNav[i].repaint();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            configurarUIDefaults();
            new JanelaPrincipal().setVisible(true);
        });
    }

    private static void configurarUIDefaults() {
        UIManager.put("OptionPane.background", Tema.FUNDO_CARD);
        UIManager.put("Panel.background", Tema.FUNDO_CARD);
        UIManager.put("OptionPane.messageForeground", Tema.TEXTO_PRINCIPAL);
        UIManager.put("Button.background", Tema.FUNDO_CAMPO);
        UIManager.put("Button.foreground", Tema.TEXTO_PRINCIPAL);
        UIManager.put("ComboBox.background", Tema.FUNDO_CAMPO);
        UIManager.put("ComboBox.foreground", Tema.TEXTO_PRINCIPAL);
        UIManager.put("TextField.background", Tema.FUNDO_CAMPO);
        UIManager.put("TextField.foreground", Tema.TEXTO_PRINCIPAL);
        UIManager.put("TextArea.background", Tema.FUNDO_CAMPO);
        UIManager.put("TextArea.foreground", Tema.TEXTO_PRINCIPAL);
    }
}