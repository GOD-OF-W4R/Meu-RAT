package c;

import java.util.List;

/**
 * Interface que define o contrato para gestores de encomendas
 * Utiliza padrão Strategy para permitir diferentes implementações
 * 
 * @author Sistema Fikissa
 */
public interface IGestor {
    
    // ========== OPERAÇÕES COM ENCOMENDAS ==========
    void cadastrarEncomenda(Encomenda encomenda);
    void editarEncomenda(Encomenda encomenda);
    void excluirEncomenda(String codigo);
    Encomenda buscarEncomendaPorCodigo(String codigo);
    List<Encomenda> listarEncomendas();
    List<Encomenda> getEncomendasStockBaixo();
    
    // ========== OPERAÇÕES COM CLIENTES ==========
    void cadastrarCliente(Cliente cliente);
    Cliente buscarClientePorId(String id);
    List<Cliente> listarClientes();
    void editarCliente(Cliente cliente);
    void excluirCliente(String id);
    String gerarIdCliente();
    
    // ========== OPERAÇÕES COM MOVIMENTAÇÕES ==========
    void registrarMovimentacao(String codigoEncomenda, int quantidade, TipoMovimentacao tipo, String obs);
    List<Movimentacao> getHistorico();
    
    // ========== RELATÓRIOS ==========
    double getValorTotalStock();
    int getTotalEncomendasActivas();
    int getTotalClientes();
    int getTotalMovimentacoes();
    
    // ========== PERSISTÊNCIA ==========
    void salvarDados();
    void carregarDados();
}
