
package c;
import java.io.*;
import java.time.LocalDate;

public class EncomendaTest implements Serializable {
    private static final long serialVersionUID = 1L;

    private String codigo;               // único, ex: ENC001
    private String descricao;            // descrição sucinta
    private int prazoEntrega;            // em dias (1, 2, ...)
    private double massa;                // kg
    private double volume;               // m³
    private String localOrigem;
    private String localDestino;
    private String contactoRemetente;
    private String enderecoRemetente;
    private String contactoDestinatario;
    private String enderecoDestinatario;
    private int quantidadeStock;          // nível atual
    private int quantidadeMinima;         // para alerta
    private String status;                // PENDENTE, ENTREGUE, CANCELADA
    private Cliente cliente;              // cliente associado (remetente ou destinatário)

    public EncomendaTest(String codigo, String descricao, int prazoEntrega, double massa, double volume,
                     String localOrigem, String localDestino, String contactoRemetente,
                     String enderecoRemetente, String contactoDestinatario, String enderecoDestinatario) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.prazoEntrega = prazoEntrega;
        this.massa = massa;
        this.volume = volume;
        this.localOrigem = localOrigem;
        this.localDestino = localDestino;
        this.contactoRemetente = contactoRemetente;
        this.enderecoRemetente = enderecoRemetente;
        this.contactoDestinatario = contactoDestinatario;
        this.enderecoDestinatario = enderecoDestinatario;
        this.quantidadeStock = 0;
        this.quantidadeMinima = 5;   // valor padrão
        this.status = "PENDENTE";
        this.cliente = null;
    }

    public double calcularTaxaEnvio() {
       // Taxa base: 2 por kg + 100 por m³
        return (this.massa * 2) + (this.volume * 100);
    }

    public boolean precisaRepor()
    {
        return quantidadeStock <= quantidadeMinima;
    }

   
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public int getPrazoEntrega() { return prazoEntrega; }
    public void setPrazoEntrega(int prazoEntrega) { this.prazoEntrega = prazoEntrega; }
    public double getMassa() { return massa; }
    public void setMassa(double massa) { this.massa = massa; }
    public double getVolume() { return volume; }
    public void setVolume(double volume) { this.volume = volume; }
    public String getLocalOrigem() { return localOrigem; }
    public void setLocalOrigem(String localOrigem) { this.localOrigem = localOrigem; }
    public String getLocalDestino() { return localDestino; }
    public void setLocalDestino(String localDestino) { this.localDestino = localDestino; }
    public String getContactoRemetente() { return contactoRemetente; }
    public void setContactoRemetente(String contactoRemetente) { this.contactoRemetente = contactoRemetente; }
    public String getEnderecoRemetente() { return enderecoRemetente; }
    public void setEnderecoRemetente(String enderecoRemetente) { this.enderecoRemetente = enderecoRemetente; }
    public String getContactoDestinatario() { return contactoDestinatario; }
    public void setContactoDestinatario(String contactoDestinatario) { this.contactoDestinatario = contactoDestinatario; }
    public String getEnderecoDestinatario() { return enderecoDestinatario; }
    public void setEnderecoDestinatario(String enderecoDestinatario) { this.enderecoDestinatario = enderecoDestinatario; }
    public int getQuantidadeStock() { return quantidadeStock; }
    public void setQuantidadeStock(int quantidadeStock) { this.quantidadeStock = quantidadeStock; }
    public int getQuantidadeMinima() { return quantidadeMinima; }
    public void setQuantidadeMinima(int quantidadeMinima) { this.quantidadeMinima = quantidadeMinima; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    @Override
    public String toString() {
        return codigo + " - " + descricao + " (Stock: " + quantidadeStock + ")";
    }
}