package c;

import java.io.*;
import java.util.regex.Pattern;

/**
 * Classe Cliente - Representa um cliente no sistema Fikissa
 * 
 * Propriedades:
 * - Identificado por ID único
 * - Contacto e endereço obrigatórios
 * - Email validado por regex
 * - Implementa Comparable para ordenação
 * 
 * @author Sistema Fikissa
 * @version 2.0
 */
public class Cliente implements Serializable, Comparable<Cliente> {
    private static final long serialVersionUID = 1L;
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    private String id;
    private String nome;
    private String contacto;
    private String endereco;
    private String condicoesPagamento;
    private String email;

    /**
     * Construtor do Cliente
     */
    public Cliente(String id, String nome, String contacto, String endereco, 
                   String condicoesPagamento, String email) {
        validarDados(id, nome, contacto, endereco, email);
        
        this.id = id;
        this.nome = nome;
        this.contacto = contacto;
        this.endereco = endereco;
        this.condicoesPagamento = condicoesPagamento != null ? condicoesPagamento : "";
        this.email = email;
    }

    /**
     * Valida os dados do cliente
     */
    private void validarDados(String id, String nome, String contacto, String endereco, String email) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID do cliente não pode estar vazio.");
        }
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do cliente não pode estar vazio.");
        }
        if (contacto == null || contacto.trim().isEmpty()) {
            throw new IllegalArgumentException("Contacto do cliente não pode estar vazio.");
        }
        if (endereco == null || endereco.trim().isEmpty()) {
            throw new IllegalArgumentException("Endereço do cliente não pode estar vazio.");
        }
        if (email != null && !email.trim().isEmpty() && !isEmailValido(email)) {
            throw new IllegalArgumentException("Email inválido: " + email);
        }
    }

    /**
     * Valida formato de email
     */
    private static boolean isEmailValido(String email) {
        return EMAIL_PATTERN.matcher(email).matches();
    }

    /**
     * Implementação de Comparable para ordenação por ID
     */
    @Override
    public int compareTo(Cliente outro) {
        return this.id.compareTo(outro.id);
    }

    // ========== GETTERS E SETTERS ==========

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID não pode estar vazio.");
        }
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome não pode estar vazio.");
        }
        this.nome = nome;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        if (contacto == null || contacto.trim().isEmpty()) {
            throw new IllegalArgumentException("Contacto não pode estar vazio.");
        }
        this.contacto = contacto;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        if (endereco == null || endereco.trim().isEmpty()) {
            throw new IllegalArgumentException("Endereço não pode estar vazio.");
        }
        this.endereco = endereco;
    }

    public String getCondicoesPagamento() {
        return condicoesPagamento;
    }

    public void setCondicoesPagamento(String condicoesPagamento) {
        this.condicoesPagamento = condicoesPagamento != null ? condicoesPagamento : "";
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email != null && !email.trim().isEmpty() && !isEmailValido(email)) {
            throw new IllegalArgumentException("Email inválido: " + email);
        }
        this.email = email;
    }

    @Override
    public String toString() {
        return nome + " (" + contacto + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || !(obj instanceof Cliente)) return false;
        Cliente outro = (Cliente) obj;
        return this.id.equals(outro.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
