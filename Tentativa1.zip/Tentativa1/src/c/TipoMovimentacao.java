package c;

/**
 * Enumeração para os tipos de movimentação de stock
 * Define se é entrada ou saída de stock
 * 
 * @author Sistema Fikissa
 */
public enum TipoMovimentacao {
    ENTRADA("Entrada", "Aumento de stock"),
    SAIDA("Saída", "Diminuição de stock");

    private final String descricao;
    private final String tooltip;

    TipoMovimentacao(String descricao, String tooltip) {
        this.descricao = descricao;
        this.tooltip = tooltip;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getTooltip() {
        return tooltip;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
