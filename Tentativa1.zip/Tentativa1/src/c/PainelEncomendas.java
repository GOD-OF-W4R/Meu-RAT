package c;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class PainelEncomendas extends JPanel {
	
    private GestorEncomendas gestor;
    private JTable tabela;
    private DefaultTableModel modeloTabela;

    public PainelEncomendas(GestorEncomendas gestor) {
        this.gestor = gestor;
        setBackground(Tema.FUNDO_PRINCIPAL);
        setLayout(new BorderLayout());
        construir();
        carregarTabela();
    }

    private void construir() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        header.add(Componentes.labelTitulo("📦 Encomendas"), BorderLayout.WEST);

        JButton btnNova = new Componentes.BotaoVerde("+ Nova Encomenda");
        btnNova.addActionListener(e -> abrirDialogoEncomenda());
        
        JButton btnRemover = new Componentes.BotaoPerigo("Remover Encomenda");
        btnRemover.addActionListener(e -> removerEncomendaSelecionada());
        
        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoes.setOpaque(false);
        acoes.add(btnRemover);
        acoes.add(btnNova);
        header.add(acoes, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        String[] colunas = {"Código", "Descrição", "Prazo", "Massa", "Volume", "Origem", "Destino", "Stock", "Status"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modeloTabela);
        estilizarTabela();
        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
        add(scroll, BorderLayout.CENTER);
    }

    private void removerEncomendaSelecionada() {
        int linha = tabela.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma encomenda primeiro.");
            return;
        }

        String codigo = (String) modeloTabela.getValueAt(linha, 0);
        try {
            gestor.excluirEncomenda(codigo);
            carregarTabela();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage(), "Remoção", JOptionPane.ERROR_MESSAGE);
        }
    }
	private void estilizarTabela() {
        tabela.setBackground(Tema.FUNDO_CARD);
        tabela.setForeground(Tema.TEXTO_PRINCIPAL);
        tabela.setFont(Tema.fonteCorpo(13));
        tabela.setRowHeight(30);
    }

    private void carregarTabela() {
        modeloTabela.setRowCount(0);
        List<EncomendaTest> lista = gestor.listarEncomendas();
        for (EncomendaTest e : lista) {
            modeloTabela.addRow(new Object[]{
                e.getCodigo(), e.getDescricao(), e.getPrazoEntrega(),
                e.getMassa(), e.getVolume(), e.getLocalOrigem(),
                e.getLocalDestino(), e.getQuantidadeStock(), e.getStatus()
            });
        }
    }

    private void abrirDialogoEncomenda() {
        String codigoGerado = gestor.gerarCodigoEncomenda(); // gera automaticamente

        JTextField descricaoField = new JTextField();
        JTextField prazoField = new JTextField();
        JTextField massaField = new JTextField();
        JTextField volumeField = new JTextField();
        JTextField origemField = new JTextField();
        JTextField destinoField = new JTextField();
        JTextField contactoRemField = new JTextField();
        JTextField enderecoRemField = new JTextField();
        JTextField contactoDestField = new JTextField();
        JTextField enderecoDestField = new JTextField();

        Object[] campos = {
            "Código : " + codigoGerado,
            "Descrição:", descricaoField,
            "Prazo Entrega (dias):", prazoField,
            "Massa (kg):", massaField,
            "Volume (m³):", volumeField,
            "Local Origem:", origemField,
            "Local Destino:", destinoField,
            "Contacto Remetente:", contactoRemField,
            "Endereço Remetente:", enderecoRemField,
            "Contacto Destinatário:", contactoDestField,
            "Endereço Destinatário:", enderecoDestField
        };

        int opcao = JOptionPane.showConfirmDialog(this, campos, "Nova Encomenda", JOptionPane.OK_CANCEL_OPTION);
        if (opcao == JOptionPane.OK_OPTION) 
        {
            try {
                EncomendaTest nova = new EncomendaTest(
                    codigoGerado,
                    descricaoField.getText(),
                    Integer.parseInt(prazoField.getText()),
                    Double.parseDouble(massaField.getText()),
                    Double.parseDouble(volumeField.getText()),
                    origemField.getText(),
                    destinoField.getText(),
                    contactoRemField.getText(),
                    enderecoRemField.getText(),
                    contactoDestField.getText(),
                    enderecoDestField.getText()
                );
            

                validarEncomenda(nova);
                gestor.cadastrarEncomenda(nova);
                carregarTabela();//
               } 
        
            catch (Exception ex)
            {
                JOptionPane.showMessageDialog(null, ex.getMessage());   
             }
        }
    }
        
        private void validarEncomenda(EncomendaTest e) {
            if (e.getCodigo() == null || e.getCodigo().isEmpty())
                throw new IllegalArgumentException("Código é obrigatório.");
            if (e.getDescricao() == null || e.getDescricao().isEmpty())
                throw new IllegalArgumentException("Descrição é obrigatória.");
            if (e.getPrazoEntrega() <= 0)
                throw new IllegalArgumentException("Prazo de entrega deve ser maior que 0.");
            if (e.getMassa() <= 0 || e.getVolume() <= 0)
                throw new IllegalArgumentException("Massa e volume devem ser positivos.");
        }
        
        
        
      
        
        
    }


