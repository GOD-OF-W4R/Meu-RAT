package c;


import java.awt.*;

public class Tema {
    // Paleta de cores
    public static final Color FUNDO_PRINCIPAL   = new Color(10, 14, 20);
    public static final Color FUNDO_CARD        = new Color(18, 24, 35);
    public static final Color FUNDO_CAMPO       = new Color(22, 30, 44);
    public static final Color VERDE_CAMPO       = new Color(39, 174, 96);
    public static final Color VERDE_ESCURO      = new Color(22, 120, 64);
    public static final Color DOURADO           = new Color(212, 175, 55);
    public static final Color DOURADO_CLARO     = new Color(255, 215, 0);
    public static final Color TEXTO_PRINCIPAL   = new Color(230, 235, 245);
    public static final Color TEXTO_SECUNDARIO  = new Color(130, 145, 170);
    public static final Color DESTAQUE_ALERTA   = new Color(231, 76, 60);
    public static final Color DESTAQUE_INFO     = new Color(52, 152, 219);
    public static final Color BORDA_SUTIL       = new Color(35, 45, 65);
    public static final Color HOVER_CARD        = new Color(28, 36, 52);
    public static final Color AZUL_ESCURO       = new Color(15, 30, 60);

    // Metodos para fontes 
    public static Font fonteTitulo(float size) {
        return new Font("Georgia", Font.BOLD, (int) size);
    }
    public static Font fonteSubtitulo(float size) {
        return new Font("Tahoma", Font.BOLD, (int) size);
    }
    public static Font fonteCorpo(float size) {
        return new Font("Tahoma", Font.PLAIN, (int) size);
    }
    public static Font fonteMonospaceda(float size) {
        return new Font("Courier New", Font.PLAIN, (int) size);
    }

    // Metodo utilitario para desenhar cards arredondados
    public static void drawRoundCard(Graphics2D g2, int x, int y, int w, int h, int arc, Color bg, Color border) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(bg);
        g2.fillRoundRect(x, y, w, h, arc, arc);
        if (border != null) {
            g2.setColor(border);
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRoundRect(x, y, w, h, arc, arc);
        }
    }
}