package c;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

public class LoginFrame extends JFrame {

    private JComboBox<String> usuarioBox;
    private JPasswordField senhaField;
    private JButton btnLogin;

    // Mapa de utilizadores e respetivas senhas
    private Map<String, String> usuarios;

    public LoginFrame() {
        setTitle("Login - Gestor Fikissa");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Inicializa utilizadores
        usuarios = new HashMap<>();
        usuarios.put("Claricia", "1234");
        usuarios.put("Amelia", "0000");
        usuarios.put("Danilo", "0001");
        usuarios.put("Kleyton", "0000");
        usuarios.put("Herson", "0000");

        // Cabeçalho estilizado com Tema
        JLabel titulo = new JLabel("Gestor Fikissa", SwingConstants.CENTER);
        titulo.setFont(Tema.fonteTitulo(28));
        titulo.setForeground(Tema.VERDE_CAMPO);
        titulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Painel central
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBackground(Tema.FUNDO_PRINCIPAL);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblUsuario = new JLabel("Nome do Utilizador:");
        lblUsuario.setFont(Tema.fonteSubtitulo(16));
        lblUsuario.setForeground(Tema.TEXTO_PRINCIPAL);
        gbc.gridx = 0; gbc.gridy = 0;
        painel.add(lblUsuario, gbc);

        usuarioBox = new JComboBox<>(usuarios.keySet().toArray(new String[0]));
        usuarioBox.setFont(Tema.fonteCorpo(16));
        gbc.gridx = 1; gbc.gridy = 0;
        painel.add(usuarioBox, gbc);

        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setFont(Tema.fonteSubtitulo(16));
        lblSenha.setForeground(Tema.TEXTO_PRINCIPAL);
        gbc.gridx = 0; gbc.gridy = 1;
        painel.add(lblSenha, gbc);

        senhaField = new JPasswordField();
        senhaField.setFont(Tema.fonteCorpo(16));
        gbc.gridx = 1; gbc.gridy = 1;
        painel.add(senhaField, gbc);

        btnLogin = new JButton("Entrar");
        btnLogin.setFont(Tema.fonteTitulo(16));
        btnLogin.setBackground(Tema.VERDE_CAMPO);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        gbc.gridx = 1; gbc.gridy = 2;
        painel.add(btnLogin, gbc);

        add(painel, BorderLayout.CENTER);

        // Ação do botão validad o utlilizador e senha
        btnLogin.addActionListener(e -> autenticar());
    }

    private void autenticar() {
        String usuarioSelecionado = (String) usuarioBox.getSelectedItem();
        String senhaDigitada = new String(senhaField.getPassword());

        String senhaCorreta = usuarios.get(usuarioSelecionado);

        if (senhaDigitada.equals(senhaCorreta)) {
            JOptionPane.showMessageDialog(this,   usuarioSelecionado + ", bem-vindo ao Sistema de  Gestao de Encomendas da Fikissa!");
            dispose();
            new JanelaPrincipal().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Senha inválida para " + usuarioSelecionado, "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
