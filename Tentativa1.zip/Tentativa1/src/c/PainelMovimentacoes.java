package c;


import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class PainelMovimentacoes extends JPanel {

    private GestorEncomendas gestor;
    private JTable tabela;
    private DefaultTableModel modeloTabela;

    public PainelMovimentacoes(GestorEncomendas gestor) {
        this.gestor = gestor;
        setBackground(Tema.FUNDO_PRINCIPAL);
        setLayout(new BorderLayout());
        construir();
        carregarTabela();
    }

    private void construir() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        header.add(Componentes.labelTitulo("🔄 Movimentações de Stock"), BorderLayout.WEST);

        JButton btnNova = new Componentes.BotaoVerde("+ Nova Movimentação");
        btnNova.addActionListener(e -> abrirDialogoMovimentacao());
        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        acoes.setOpaque(false);
        acoes.add(btnNova);
        header.add(acoes, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        String[] colunas = {"ID", "Encomenda", "Tipo", "Quantidade", "Data", "Observação"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modeloTabela);
        estilizarTabela();
        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
        add(scroll, BorderLayout.CENTER);
    }

    private void estilizarTabela() {
        tabela.setBackground(Tema.FUNDO_CARD);
        tabela.setForeground(Tema.TEXTO_PRINCIPAL);
        tabela.setFont(Tema.fonteCorpo(13));
        tabela.setRowHeight(30);
    }

    private void carregarTabela() {
        modeloTabela.setRowCount(0);
        List<Movimentacao> hist = gestor.getHistorico();
        for (Movimentacao m : hist) {
            modeloTabela.addRow(new Object[]{
                m.getId(), m.getEncomenda().getCodigo(), m.getTipo(),
                m.getQuantidade(), m.getData(), m.getObservacao()
            });
        }
    }

    private void abrirDialogoMovimentacao() {
        JTextField codigoEncomendaField = new JTextField();
        JTextField quantidadeField = new JTextField();
        JComboBox<String> tipoBox = new JComboBox<>(new String[]{"ENTRADA", "SAIDA"});
        JTextField observacaoField = new JTextField();

        Object[] campos = {
            "Código da Encomenda:", codigoEncomendaField,
            "Quantidade:", quantidadeField,
            "Tipo:", tipoBox,
            "Observação:", observacaoField
        };

        int opcao = JOptionPane.showConfirmDialog(this, campos, "Nova Movimentação", JOptionPane.OK_CANCEL_OPTION);
        if (opcao == JOptionPane.OK_OPTION) {
            try {
                String codigo = codigoEncomendaField.getText().trim();
                int quantidade = Integer.parseInt(quantidadeField.getText().trim());
                Movimentacao.Tipo tipo = tipoBox.getSelectedItem().equals("ENTRADA") 
                        ? Movimentacao.Tipo.ENTRADA 
                        : Movimentacao.Tipo.SAIDA;
                String obs = observacaoField.getText().trim();

                // Validação simples
                if (codigo.isEmpty()) throw new IllegalArgumentException("Código da encomenda é obrigatório.");
                if (quantidade <= 0) throw new IllegalArgumentException("Quantidade deve ser maior que 0.");
                if (obs.isEmpty()) throw new IllegalArgumentException("Observação é obrigatória.");

                gestor.registrarMovimentacao(codigo, quantidade, tipo, obs);
                carregarTabela(); // atualiza tabela
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage(), "Validação", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}