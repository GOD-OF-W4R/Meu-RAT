package c;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.event.*;

/**
 * Classe Componentes - Biblioteca de componentes UI reutilizáveis
 * Implementa padrão Facade para simplificar criação de componentes estilizados
 * 
 * Componentes fornecidos:
 * - Botões: BotaoVerde, BotaoDourado, BotaoPerigo, BotaoInfo
 * - Campos: CampoTexto, CampoArea, ComboPersonalizado
 * - Labels: labelCampo, labelTitulo, labelSecao
 * - Painéis: PainelCard
 * - ScrollPane: scrollEscuro
 * - Diálogos: mostrarErro, mostrarSucesso, confirmar
 * 
 * Todos utilizam paleta de cores Tema.java para consistência
 */
public class Componentes {

    // ================= BOTÕES CUSTOMIZADOS =================

    /**
     * Classe BotaoVerde - Botão base com efeito hover personalizado
     * Propriedades:
     * - Fundo arredondado com 10px de raio
     * - Efeito hover com mudança de cor
     * - Ícone de mão ao passar (HAND_CURSOR)
     * - Renderização customizada com brilho superior
     */
    public static class BotaoVerde extends JButton {
        private boolean hover = false;           // Flag para estado hover
        private Color corPrimaria;               // Cor normal
        private Color corHover;                  // Cor ao passar o mouse

        /**
         * Construtor com cores padrão do tema
         */
        public BotaoVerde(String texto) {
            this(texto, Tema.VERDE_CAMPO, Tema.VERDE_ESCURO);
        }

        /**
         * Construtor com cores customizadas
         */
        public BotaoVerde(String texto, Color primaria, Color hoverCor) {
            super(texto);
            this.corPrimaria = primaria;
            this.corHover = hoverCor;
            setOpaque(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setForeground(Color.WHITE);
            setFont(Tema.fonteSubtitulo(13));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(getPreferredSize().width + 30, 38));
            
            // Listeners para hover
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                public void mouseExited(MouseEvent e)  { hover = false; repaint(); }
            });
        }

        /**
         * Renderização customizada com cantos arredondados e brilho
         */
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Seleciona cor baseada em hover
            Color c = hover ? corHover : corPrimaria;
            g2.setColor(c);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            
            // Brilho no topo
            g2.setColor(new Color(255, 255, 255, 30));
            g2.fillRoundRect(0, 0, getWidth(), getHeight()/2, 10, 10);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /**
     * Classe BotaoDourado - Botão com cores douradas (ações secundárias)
     */
    public static class BotaoDourado extends BotaoVerde {
        public BotaoDourado(String texto) {
            super(texto, Tema.DOURADO, new Color(180, 145, 20));
            setForeground(new Color(20, 20, 20));  // Texto escuro para contraste
        }
    }

    /**
     * Classe BotaoPerigo - Botão com cores vermelhas (deletar, cancelar)
     */
    public static class BotaoPerigo extends BotaoVerde {
        public BotaoPerigo(String texto) {
            super(texto, Tema.DESTAQUE_ALERTA, new Color(180, 50, 40));
        }
    }

    /**
     * Classe BotaoInfo - Botão com cores azuis (informação, ajuda)
     */
    public static class BotaoInfo extends BotaoVerde {
        public BotaoInfo(String texto) {
            super(texto, Tema.DESTAQUE_INFO, new Color(30, 110, 180));
        }
    }

    // ================= CAMPOS DE ENTRADA =================

    /**
     * Classe CampoTexto - JTextField customizado com placeholder
     * Propriedades:
     * - Placeholder (texto dica) que desaparece ao digitar
     * - Borda arredondada que muda cor com focus
     * - Cores de fundo e texto do tema
     */
    public static class CampoTexto extends JTextField {
        private String placeholder;               // Texto de placeholder
        private boolean focado = false;           // Flag para estado focado

        /**
         * Construtor com placeholder
         */
        public CampoTexto(String placeholder) {
            this.placeholder = placeholder;
            setOpaque(false);
            setBackground(Tema.FUNDO_CAMPO);
            setForeground(Tema.TEXTO_PRINCIPAL);
            setCaretColor(Tema.VERDE_CAMPO);
            setFont(Tema.fonteCorpo(13));
            setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
            setPreferredSize(new Dimension(200, 38));
            
            // Listeners para detectar focus
            addFocusListener(new FocusAdapter() {
                public void focusGained(FocusEvent e) { focado = true; repaint(); }
                public void focusLost(FocusEvent e)   { focado = false; repaint(); }
            });
        }

        /**
         * Renderização customizada com borda dinâmica e placeholder
         */
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Fundo arredondado
            g2.setColor(Tema.FUNDO_CAMPO);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            
            // Borda (mais grossa se focado)
            Color borda = focado ? Tema.VERDE_CAMPO : Tema.BORDA_SUTIL;
            g2.setColor(borda);
            g2.setStroke(new BasicStroke(focado ? 2f : 1f));
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
            g2.dispose();
            
            super.paintComponent(g);
            
            // Desenha placeholder se vazio e não focado
            if (getText().isEmpty() && !isFocusOwner()) {
                Graphics2D g3 = (Graphics2D) g.create();
                g3.setColor(Tema.TEXTO_SECUNDARIO);
                g3.setFont(Tema.fonteCorpo(12));
                FontMetrics fm = g3.getFontMetrics();
                g3.drawString(placeholder, 12, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g3.dispose();
            }
        }
    }

    /**
     * Classe CampoArea - JTextArea customizado para áreas de texto grandes
     * Propriedades:
     * - Word-wrap ativado
     * - Borda composta com linhas
     * - Cores do tema
     */
    public static class CampoArea extends JTextArea {
        public CampoArea(int rows, int cols) {
            super(rows, cols);
            setOpaque(true);
            setBackground(Tema.FUNDO_CAMPO);
            setForeground(Tema.TEXTO_PRINCIPAL);
            setCaretColor(Tema.VERDE_CAMPO);
            setFont(Tema.fonteCorpo(13));
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Tema.BORDA_SUTIL, 1, true),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
            ));
            setLineWrap(true);
            setWrapStyleWord(true);
        }
    }

    /**
     * Classe ComboPersonalizado - JComboBox customizado
     * Propriedades:
     * - Cores personalizadas para caixas de seleção
     * - Renderer customizado para itens
     * - Suporta genéricos (tipo T)
     */
    public static class ComboPersonalizado<T> extends JComboBox<T> {
        public ComboPersonalizado() {
            setBackground(Tema.FUNDO_CAMPO);
            setForeground(Tema.TEXTO_PRINCIPAL);
            setFont(Tema.fonteCorpo(13));
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Tema.BORDA_SUTIL, 1, true),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)
            ));
            setPreferredSize(new Dimension(200, 38));
            
            // Renderer customizado para cores e fontes
            setRenderer(new DefaultListCellRenderer() {
                public Component getListCellRendererComponent(JList<?> list, Object value,
                        int index, boolean isSelected, boolean cellHasFocus) {
                    super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                    setBackground(isSelected ? Tema.VERDE_ESCURO : Tema.FUNDO_CAMPO);
                    setForeground(Tema.TEXTO_PRINCIPAL);
                    setFont(Tema.fonteCorpo(13));
                    setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                    return this;
                }
            });
        }
    }

    // ================= LABELS AUXILIARES =================

    /**
     * Cria JLabel para labels de campos (secundário)
     */
    public static JLabel labelCampo(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(Tema.TEXTO_SECUNDARIO);
        l.setFont(Tema.fonteCorpo(12));
        return l;
    }

    /**
     * Cria JLabel para títulos principais
     */
    public static JLabel labelTitulo(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(Tema.TEXTO_PRINCIPAL);
        l.setFont(Tema.fonteTitulo(20));
        return l;
    }

    /**
     * Cria JLabel para títulos de seção (dourado)
     */
    public static JLabel labelSecao(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(Tema.DOURADO);
        l.setFont(Tema.fonteSubtitulo(14));
        return l;
    }

    // ================= PAINÉIS =================

    /**
     * Classe PainelCard - JPanel com cantos arredondados e borda
     * Usado como container visual para diferentes seções
     * Propriedades:
     * - Renderização customizada com cantos arredondados
     * - Borda suave
     * - Fundo do tema
     */
    public static class PainelCard extends JPanel {
        private int arc;                  // Raio dos cantos arredondados
        private Color corFundo;           // Cor de fundo
        private Color corBorda;           // Cor da borda

        /**
         * Construtor com cores padrão do tema
         */
        public PainelCard() {
            this(Tema.FUNDO_CARD, Tema.BORDA_SUTIL, 12);
        }

        /**
         * Construtor com cores customizadas
         */
        public PainelCard(Color fundo, Color borda, int arc) {
            this.corFundo = fundo;
            this.corBorda = borda;
            this.arc = arc;
            setOpaque(false);
        }

        /**
         * Renderização com cantos arredondados
         */
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(corFundo);
            g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, arc, arc);
            g2.setColor(corBorda);
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, arc, arc);
            g2.dispose();
        }
    }

    // ================= SCROLL PANE =================

    /**
     * Cria JScrollPane escuro com scrollbar estilizada
     * Scrollbar verde que se destaca no fundo escuro
     */
    public static JScrollPane scrollEscuro(Component c) {
        JScrollPane scroll = new JScrollPane(c);
        scroll.setBackground(Tema.FUNDO_PRINCIPAL);
        scroll.getViewport().setBackground(Tema.FUNDO_PRINCIPAL);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        
        // Scrollbar vertical customizada
        scroll.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            protected void configureScrollBarColors() {
                thumbColor = Tema.VERDE_ESCURO;
                trackColor = Tema.FUNDO_CARD;
            }
            protected JButton createDecreaseButton(int o) { return botaoInvisivel(); }
            protected JButton createIncreaseButton(int o) { return botaoInvisivel(); }
            private JButton botaoInvisivel() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });
        
        // Scrollbar horizontal customizada
        scroll.getHorizontalScrollBar().setUI(new BasicScrollBarUI() {
            protected void configureScrollBarColors() {
                thumbColor = Tema.VERDE_ESCURO;
                trackColor = Tema.FUNDO_CARD;
            }
            protected JButton createDecreaseButton(int o) { return botaoInvisivel(); }
            protected JButton createIncreaseButton(int o) { return botaoInvisivel(); }
            private JButton botaoInvisivel() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });
        return scroll;
    }

    // ================= DIÁLOGOS E MENSAGENS =================

    /**
     * Exibe diálogo de erro
     */
    public static void mostrarErro(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Erro de Validação", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Exibe diálogo de sucesso
     */
    public static void mostrarSucesso(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Exibe diálogo de confirmação
     * @return true se utilizador clicou "Sim", false caso contrário
     */
    public static boolean confirmar(Component parent, String msg) {
        int r = JOptionPane.showConfirmDialog(parent, msg, "Confirmação", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        return r == JOptionPane.YES_OPTION;
    }
}