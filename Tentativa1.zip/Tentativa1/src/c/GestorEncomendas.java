package c;
    import javax.swing.*;
    import java.awt.*;
	import java.io.*;
    import java.time.LocalDate;
	import java.util.Comparator;
	import java.util.List;
	import java.util.concurrent.atomic.AtomicInteger;

	public class GestorEncomendas {
	    private ArvoreBinaria<EncomendaTest> arvoreEncomendas;   // organizada por código
	    private ArvoreBinaria<Cliente> arvoreClientes;       // organizada por id
	    private List<Movimentacao> historico;                // pode usar ArrayList ou a sua Fila Ligada
	    private int contadorMov=1;
	    private int contadorCli=1;
	    private int contadorEnc=1;  // contador de encomendas

	    public GestorEncomendas() {
	    	 arvoreEncomendas = new ArvoreBinaria<>();
	    	    arvoreClientes = new ArvoreBinaria<>();
	    	    historico = new java.util.ArrayList<>();
	    	 
	    	   
	    	  
	    	    carregarDados();  	 
	    }

	    //  ENCOMENDAS (arvore)
	    public void cadastrarEncomenda(EncomendaTest e) {
	        if (buscarEncomendaPorCodigo(e.getCodigo()) != null)
	            throw new IllegalArgumentException("Já existe encomenda com este código.");
	        arvoreEncomendas.inserir(e, Comparator.comparing(EncomendaTest::getCodigo));
	    }

	    public void editarEncomenda(EncomendaTest atualizada) {
	    	EncomendaTest existente = buscarEncomendaPorCodigo(atualizada.getCodigo());
	        if (existente == null) throw new IllegalArgumentException("Encomenda não encontrada.");
	        existente.setDescricao(atualizada.getDescricao());
	        existente.setPrazoEntrega(atualizada.getPrazoEntrega());
	        existente.setMassa(atualizada.getMassa());
	        existente.setVolume(atualizada.getVolume());
	        existente.setLocalOrigem(atualizada.getLocalOrigem());
	        existente.setLocalDestino(atualizada.getLocalDestino());
	        existente.setContactoRemetente(atualizada.getContactoRemetente());
	        existente.setEnderecoRemetente(atualizada.getEnderecoRemetente());
	        existente.setContactoDestinatario(atualizada.getContactoDestinatario());
	        existente.setEnderecoDestinatario(atualizada.getEnderecoDestinatario());
	        existente.setQuantidadeMinima(atualizada.getQuantidadeMinima());
	        existente.setStatus(atualizada.getStatus());
	        existente.setCliente(atualizada.getCliente());
	    }

	    public void excluirEncomenda(String codigo) {
	        boolean removida = arvoreEncomendas.remover(e -> e.getCodigo().equals(codigo), Comparator.comparing(EncomendaTest::getCodigo));
	        if (!removida) throw new IllegalArgumentException("Encomenda não encontrada.");
	    }

	    public EncomendaTest buscarEncomendaPorCodigo(String codigo) {
	        return arvoreEncomendas.buscar(e -> e.getCodigo().equals(codigo));
	    }

	    public List<EncomendaTest> listarEncomendas() {
	        return arvoreEncomendas.emOrdem();
	    }

	    public List<EncomendaTest>  getEncomendasStockBaixo() {
	        return arvoreEncomendas.filtrar(EncomendaTest::precisaRepor);
	    }

	    // ========== CLIENTES (Árvore) ==========
	    public void cadastrarCliente(Cliente c) {
	        if (buscarClientePorId(c.getId()) != null)
	            throw new IllegalArgumentException("Cliente com este ID já existe.");
	        arvoreClientes.inserir(c, Comparator.comparing(Cliente::getId));
	    }

	    public Cliente buscarClientePorId(String id) {
	        return arvoreClientes.buscar(cli -> cli.getId().equals(id));
	    }

	    public List<Cliente> listarClientes() {
	        return arvoreClientes.emOrdem();
	    }

	    public String gerarIdCliente() {
	        return "CLI" + String.format("%03d", contadorCli++);
	    }

	    // ========== MOVIMENTAÇÕES (stock) ==========
	    public void registrarMovimentacao(String codigoEncomenda, int quantidade, Movimentacao.Tipo tipo, String obs) {
	    	EncomendaTest e = buscarEncomendaPorCodigo(codigoEncomenda);
	        if (e == null) throw new IllegalArgumentException("Encomenda não encontrada.");

	        if (tipo == Movimentacao.Tipo.SAIDA && e.getQuantidadeStock() < quantidade)
	            throw new IllegalArgumentException("Stock insuficiente. Disponível: " + e.getQuantidadeStock());

	        int novaQuantidade = (tipo == Movimentacao.Tipo.ENTRADA)
	                ? e.getQuantidadeStock() + quantidade
	                : e.getQuantidadeStock() - quantidade;
	        e.setQuantidadeStock(novaQuantidade);

	        String idMov = "MOV" + String.format("%03d", contadorMov++);
	        Movimentacao mov = new Movimentacao(idMov, e, tipo, quantidade, LocalDate.now(), obs);
	        historico.add(mov);

	        // Verificar alerta
	        if (e.precisaRepor()) 
	        {
	            JOptionPane.showMessageDialog(
	                null,
	                "ALERTA: Reposição necessária para " +  e.getDescricao()+
	                " - Stock atual: " + e.getQuantidadeStock(),
	                "Gestor Fikissa - Alerta de Stock",
	                JOptionPane.WARNING_MESSAGE
	            );
	        }

	           
	    }

	    public List<Movimentacao> getHistorico() { return historico; }

	    // ========== RELATÓRIOS E ANÁLISES ==========
	    public double getValorTotalStock() {
	        return arvoreEncomendas.emOrdem().stream()
	                .mapToDouble(e -> e.getQuantidadeStock() * e.calcularTaxaEnvio())
	                .sum();
	    }

	    public int getTotalEncomendasActivas() {
	        return (int) arvoreEncomendas.filtrar(e -> e.getStatus().equals("PENDENTE")).size();
	    }
	    
	    ////////
	    ///
	 // Adicionar encomenda
	    public int getTotalClientes() {
            return arvoreClientes.getTamanho();
        }

        public int getTotalMovimentacoes() {
            return historico.size();
        }

        public void cadastrarEncomenda1(EncomendaTest e) {
	        if (buscarEncomendaPorCodigo(e.getCodigo()) != null)
	            throw new IllegalArgumentException("Já existe encomenda com este código.");
	        arvoreEncomendas.inserir(e, Comparator.comparing(EncomendaTest::getCodigo));
	    }

	    // Remover encomenda
	    public void excluirEncomenda1(String codigo) 
	    {
	        boolean removido = arvoreEncomendas.remover(en -> en.getCodigo().equals(codigo), Comparator.comparing(EncomendaTest::getCodigo));
	        if (!removido) throw new IllegalArgumentException("Encomenda não encontrada.");
	    }
       
	    public String gerarCodigoEncomenda() 
	    {
            return "ENC" + String.format("%03d", contadorEnc++);
        }
       
	    
	    public void salvarDados() {
	        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("dados.ser")))
	        {
	            out.writeObject(arvoreEncomendas.emOrdem());
	            out.writeObject(arvoreClientes.emOrdem());
	            out.writeObject(historico);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    @SuppressWarnings("unchecked")
	    public void carregarDados() {
	        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("dados.ser"))) {
	            List<EncomendaTest> encomendas = (List<EncomendaTest>) in.readObject();
	            List<Cliente> clientes = (List<Cliente>) in.readObject();
	            List<Movimentacao> movs = (List<Movimentacao>) in.readObject();

	            for (Cliente c : clientes) cadastrarCliente(c);
	            for (EncomendaTest e : encomendas) cadastrarEncomenda(e);
	            historico.addAll(movs);
	        } catch (Exception e) {
	            JOptionPane.showMessageDialog(null,"Nenhum ficheiro encontrado, iniciando vazio.");
	        }
	    }

		public void removerCliente(String id) {
		boolean removido = arvoreClientes.remover(cli -> cli.getId().equals(id), Comparator.comparing(Cliente::getId));
		if (!removido) {
			throw new IllegalArgumentException("Cliente não encontrado.");
		}
	}

}
