package c;
import java.io.*;
import java.time.LocalDate;

/**
 * Classe Movimentacao - Registra entradas e saídas de stock
 * 
 * Representa cada movimento de stock no sistema com rastreamento completo
 * Implementa Serializable para persistência em arquivo
 * 
 * @author Sistema Fikissa
 * @version 2.0
 */
public class Movimentacao implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum Tipo {
        ENTRADA("Entrada", "Aumento de stock"),
        SAIDA("Saída", "Diminuição de stock");

        private final String descricao;
        private final String tooltip;

        Tipo(String descricao, String tooltip) {
            this.descricao = descricao;
            this.tooltip = tooltip;
        }

        public String getDescricao() {
            return descricao;
        }

        public String getTooltip() {
            return tooltip;
        }

        @Override
        public String toString() {
            return descricao;
        }
    }

    private String id;
    private EncomendaTest encomenda;
    private Tipo tipo;
    private int quantidade;
    private LocalDate data;
    private String observacao;

    /**
     * Construtor da Movimentacao
     */
    public Movimentacao(String id, EncomendaTest encomenda, Tipo tipo, int quantidade, LocalDate data, String observacao) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID da movimentação não pode estar vazio.");
        }
        if (encomenda == null) {
            throw new IllegalArgumentException("Encomenda não pode ser nula.");
        }
        if (tipo == null) {
            throw new IllegalArgumentException("Tipo de movimentação não pode ser nulo.");
        }
        if (quantidade <= 0) {
            throw new IllegalArgumentException("Quantidade deve ser maior que 0.");
        }
        if (data == null) {
            throw new IllegalArgumentException("Data não pode ser nula.");
        }
        
        this.id = id;
        this.encomenda = encomenda;
        this.tipo = tipo;
        this.quantidade = quantidade;
        this.data = data;
        this.observacao = observacao != null ? observacao : "";
    }

    // Getters
    public String getId() { return id; }
    public EncomendaTest getEncomenda() { return encomenda; }
    public Tipo getTipo() { return tipo; }
    public int getQuantidade() { return quantidade; }
    public LocalDate getData() { return data; }
    public String getObservacao() { return observacao; }

    @Override
    public String toString() {
        return "[" + tipo.getDescricao() + "] " + encomenda.getCodigo() + " - qtd: " + quantidade + " - " + data;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || !(obj instanceof Movimentacao)) return false;
        Movimentacao outra = (Movimentacao) obj;
        return this.id.equals(outra.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}