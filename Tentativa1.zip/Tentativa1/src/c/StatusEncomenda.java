package c;

/**
 * Enumeração para os possíveis status de uma encomenda
 * Substitui a abordagem com String para maior tipagem segura
 * 
 * @author Sistema Fikissa
 */
public enum StatusEncomenda {
    PENDENTE("Pendente", "A ser processada"),
    ENTREGUE("Entregue", "Entregue com sucesso"),
    CANCELADA("Cancelada", "Operação cancelada");

    private final String descricao;
    private final String tooltip;

    StatusEncomenda(String descricao, String tooltip) {
        this.descricao = descricao;
        this.tooltip = tooltip;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getTooltip() {
        return tooltip;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
