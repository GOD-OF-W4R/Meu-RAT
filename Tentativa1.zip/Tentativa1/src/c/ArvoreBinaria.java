
package c;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

/**
 * Classe ArvoreBinaria - Estrutura de dados de árvore binária de busca genérica
 * 
 * Características:
 * - Genérica (tipo T)
 * - Suporta inserção, busca, remoção por predicado
 * - Mantém chaves únicas (sem duplicatas)
 * - Suporta filtros e percursos em-ordem
 * 
 * @param <T> Tipo de dado armazenado
 * @author Sistema Fikissa
 * @version 2.0
 */
public class ArvoreBinaria<T> {
    private NoArvore<T> raiz;
    private int tamanho;
    private boolean ultimaInsercaoBemSucedida;

    public ArvoreBinaria() {
        raiz = null;
        tamanho = 0;
        ultimaInsercaoBemSucedida = false;
    }

    /**
     * Insere um elemento baseado em comparador
     * Mantém chaves únicas (não insere duplicatas)
     * 
     * @param dado Elemento a inserir
     * @param comparador Comparador para ordenação
     */
    public void inserir(T dado, Comparator<T> comparador) {
        ultimaInsercaoBemSucedida = false;
        raiz = inserirRecursivo(raiz, dado, comparador);
        if (ultimaInsercaoBemSucedida) {
            tamanho++;
        }
    }

    private NoArvore<T> inserirRecursivo(NoArvore<T> no, T dado, Comparator<T> comp) {
        if (no == null) {
            ultimaInsercaoBemSucedida = true;
            return new NoArvore<>(dado);
        }
        if (comp.compare(dado, no.getDado()) < 0)
            no.setEsquerda(inserirRecursivo(no.getEsquerda(), dado, comp));
        else if (comp.compare(dado, no.getDado()) > 0)
            no.setDireita(inserirRecursivo(no.getDireita(), dado, comp));
        // se igual, não insere (evita duplicados)
        return no;
    }

    /**
     * Busca um elemento por predicado
     * 
     * @param condicao Predicado de busca
     * @return Primeiro elemento encontrado ou null
     */
    public T buscar(Predicate<T> condicao) {
        return buscarRecursivo(raiz, condicao);
    }

    private T buscarRecursivo(NoArvore<T> no, Predicate<T> cond) {
        if (no == null) return null;
        if (cond.test(no.getDado())) return no.getDado();
        T esq = buscarRecursivo(no.getEsquerda(), cond);
        if (esq != null) return esq;
        return buscarRecursivo(no.getDireita(), cond);
    }

    /**
     * Remove o primeiro elemento que satisfaz o predicado
     * 
     * @param condicao Predicado de remoção
     * @param comparador Comparador para ajuste de árvore
     * @return true se removido, false se não encontrado
     */
    public boolean remover(Predicate<T> condicao, Comparator<T> comparador) {
        NoArvore<T>[] resultado = removerRecursivo(raiz, null, condicao, comparador);
        if (resultado[0] != null) {
            raiz = resultado[0];
            tamanho--;
            return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private NoArvore<T>[] removerRecursivo(NoArvore<T> no, NoArvore<T> pai, Predicate<T> cond, Comparator<T> comp) {
        if (no == null) return new NoArvore[]{null, null};
        if (cond.test(no.getDado())) {
            // Nó encontrado
            NoArvore<T> substituto;
            if (no.getEsquerda() == null && no.getDireita() == null) {
                substituto = null;
            } else if (no.getEsquerda() == null) {
                substituto = no.getDireita();
            } else if (no.getDireita() == null) {
                substituto = no.getEsquerda();
            } else {
                // tem dois filhos -> menor da direita
                NoArvore<T> menor = encontrarMenor(no.getDireita());
                menor.setDireita(removerMenor(no.getDireita()));
                menor.setEsquerda(no.getEsquerda());
                substituto = menor;
            }
            if (pai == null) return new NoArvore[]{substituto, null};
            if (pai.getEsquerda() == no) pai.setEsquerda(substituto);
            else pai.setDireita(substituto);
            return new NoArvore[]{no, null};
        }
        NoArvore<T>[] esq = removerRecursivo(no.getEsquerda(), no, cond, comp);
        if (esq[0] != null) return esq;
        return removerRecursivo(no.getDireita(), no, cond, comp);
    }

    private NoArvore<T> encontrarMenor(NoArvore<T> no) {
        while (no.getEsquerda() != null) no = no.getEsquerda();
        return no;
    }

    private NoArvore<T> removerMenor(NoArvore<T> no) {
        if (no.getEsquerda() == null) return no.getDireita();
        no.setEsquerda(removerMenor(no.getEsquerda()));
        return no;
    }

    /**
     * Percurso em-ordem (esquerda-nó-direita)
     * Retorna lista ordenada
     * 
     * @return Lista de elementos em ordem
     */
    public List<T> emOrdem() {
        List<T> lista = new ArrayList<>();
        emOrdemRec(raiz, lista);
        return lista;
    }

    private void emOrdemRec(NoArvore<T> no, List<T> lista) {
        if (no != null) {
            emOrdemRec(no.getEsquerda(), lista);
            lista.add(no.getDado());
            emOrdemRec(no.getDireita(), lista);
        }
    }

    /**
     * Filtra todos os elementos que satisfazem o predicado
     * 
     * @param cond Predicado de filtro
     * @return Lista de elementos filtrados
     */
    public List<T> filtrar(Predicate<T> cond) {
        List<T> resultado = new ArrayList<>();
        filtrarRec(raiz, cond, resultado);
        return resultado;
    }

    private void filtrarRec(NoArvore<T> no, Predicate<T> cond, List<T> lista) {
        if (no != null) {
            filtrarRec(no.getEsquerda(), cond, lista);
            if (cond.test(no.getDado())) lista.add(no.getDado());
            filtrarRec(no.getDireita(), cond, lista);
        }
    }

    public int getTamanho() { return tamanho; }
    public boolean estaVazia() { return raiz == null; }
}

/**
 * Classe NoArvore - Nó interno da árvore binária
 * Encapsulamento completo com getters/setters
 * 
 * @param <T> Tipo de dado armazenado
 */
class NoArvore<T> {
    private T dado;
    private NoArvore<T> esquerda;
    private NoArvore<T> direita;

    NoArvore(T dado) {
        this.dado = dado;
        this.esquerda = null;
        this.direita = null;
    }

    // Getters
    public T getDado() { return dado; }
    public NoArvore<T> getEsquerda() { return esquerda; }
    public NoArvore<T> getDireita() { return direita; }

    // Setters
    public void setEsquerda(NoArvore<T> esquerda) { this.esquerda = esquerda; }
    public void setDireita(NoArvore<T> direita) { this.direita = direita; }
}
