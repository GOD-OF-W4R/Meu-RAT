# 📚 GUIA DE REFERÊNCIA - CLASSES E ESTRUTURAS

## 🎯 ÍNDICE RÁPIDO

| Ficheiro | Tipo | Propósito | Status |
|----------|------|----------|--------|
| `StatusEncomenda.java` | Enum | Estados de encomendas | ✅ Novo |
| `TipoMovimentacao.java` | Enum | Tipos de movimentos | ✅ Novo |
| `IGestor.java` | Interface | Contrato do gestor | ✅ Novo |
| `Constantes.java` | Classe Utilitária | Valores constantes | ✅ Novo |
| `PainelBase.java` | Classe Abstrata | Base para painéis | ✅ Novo |
| `Encomenda.java` | Classe Modelo | Entidade de encomenda | ✅ Novo |
| `Cliente.java` | Classe Modelo | Entidade de cliente | ✅ Melhorado |
| `Movimentacao.java` | Classe Modelo | Registro de movimento | ✅ Melhorado |
| `ArvoreBinaria.java` | Estrutura de Dados | Árvore binária genérica | ✅ Melhorado |
| `GestorEncomendas.java` | Classe Principal | Orquestra operações | ✅ Refatorado |
| `PainelDashboard.java` | Painel UI | Dashboard principal | ✅ Melhorado |
| `PainelEncomendas.java` | Painel UI | Gestão de encomendas | ✅ Melhorado |
| `PainelClientes.java` | Painel UI | Gestão de clientes | ✅ Melhorado |
| `PainelMovimentacoes.java` | Painel UI | Registro de movimentos | ✅ Melhorado |
| `PainelRelatorios.java` | Painel UI | Relatórios e análises | ✅ Melhorado |
| `JanelaPrincipal.java` | Janela Principal | Aplicação principal | ✅ Compatível |
| `LoginFrame.java` | Janela de Login | Autenticação | ✅ Compatível |
| `Tema.java` | Tema Visual | Paleta de cores | ✅ Compatível |
| `Componentes.java` | Componentes UI | Botões/Campos | ✅ Compatível |

---

## 🔑 ENUMS (Tipos Enumerados)

### StatusEncomenda
```java
// Substitui String "PENDENTE"
public enum StatusEncomenda {
    PENDENTE("Pendente", "A ser processada"),
    ENTREGUE("Entregue", "Entregue com sucesso"),
    CANCELADA("Cancelada", "Operação cancelada");
    
    public String getDescricao() { ... }
    public String getTooltip() { ... }
}

// Uso:
StatusEncomenda status = StatusEncomenda.PENDENTE;
encomenda.setStatus(StatusEncomenda.ENTREGUE);
if (encomenda.getStatus() == StatusEncomenda.PENDENTE) { ... }
```

### TipoMovimentacao
```java
// Substitui Movimentacao.Tipo
public enum TipoMovimentacao {
    ENTRADA("Entrada", "Aumento de stock"),
    SAIDA("Saída", "Diminuição de stock");
    
    public String getDescricao() { ... }
    public String getTooltip() { ... }
}

// Uso:
gestor.registrarMovimentacao(codigo, qtd, TipoMovimentacao.ENTRADA, "obs");
```

---

## 📋 CLASSES MODELO

### Encomenda
```java
// ✅ Novo - Substitui EncomendaTest
public class Encomenda implements Serializable, Comparable<Encomenda>

// Construtor
Encomenda enc = new Encomenda(
    "ENC001",           // código (único)
    "Roupa importada",  // descrição
    2,                  // prazo (dias)
    5.5,               // massa (kg)
    2.3,               // volume (m³)
    "Lisboa",          // localOrigem
    "Porto",           // localDestino
    "+351912345678",   // contactoRemetente
    "Rua A, Lisboa",   // enderecoRemetente
    "+351987654321",   // contactoDestinatario
    "Rua B, Porto"     // enderecoDestinatario
);

// Métodos principais
double taxa = enc.calcularTaxaEnvio();           // 2€/kg + 100€/m³
boolean necessita = enc.precisaRepor();          // stock <= quantidadeMinima
enc.setStatus(StatusEncomenda.ENTREGUE);
enc.setQuantidadeStock(10);
String desc = enc.getStatus().getDescricao();   // "Entregue"
```

### Cliente
```java
// ✅ Melhorado - Validação e Comparable
public class Cliente implements Serializable, Comparable<Cliente>

// Construtor com validação
Cliente cli = new Cliente(
    "CLI001",                      // id (único)
    "João Silva",                  // nome (obrigatório)
    "+351912345678",              // contacto (obrigatório)
    "Rua Principal, Lisboa",      // endereco (obrigatório)
    "30 dias",                    // condicoesPagamento
    "joao@email.com"              // email (validado)
);

// Email é validado automaticamente
// Exceção: IllegalArgumentException se inválido
```

### Movimentacao
```java
// ✅ Melhorado - Usa TipoMovimentacao enum
public class Movimentacao implements Serializable

// Registrar entrada de stock
Movimentacao mov = new Movimentacao(
    "MOV001",
    encomenda,
    TipoMovimentacao.ENTRADA,    // ← enum em vez de string
    50,
    LocalDate.now(),
    "Recebimento do fornecedor"
);

// Acesso aos dados
TipoMovimentacao tipo = mov.getTipo();
String descricao = tipo.getDescricao();  // "Entrada"
```

---

## 🏗️ INTERFACE E GESTOR

### IGestor (Interface)
```java
// Define contrato para qualquer implementação
public interface IGestor {
    // Encomendas
    void cadastrarEncomenda(Encomenda encomenda);
    void editarEncomenda(Encomenda encomenda);
    void excluirEncomenda(String codigo);
    Encomenda buscarEncomendaPorCodigo(String codigo);
    List<Encomenda> listarEncomendas();
    List<Encomenda> getEncomendasStockBaixo();
    
    // Clientes
    void cadastrarCliente(Cliente cliente);
    // ... mais métodos ...
    
    // Persistência
    void salvarDados();
    void carregarDados();
}
```

### GestorEncomendas (Implementação)
```java
// ✅ Implementa IGestor
public class GestorEncomendas implements IGestor

// Uso
IGestor gestor = new GestorEncomendas();
gestor.cadastrarEncomenda(encomenda);
List<Encomenda> todas = gestor.listarEncomendas();
int totalClientes = gestor.getTotalClientes();
```

---

## 📊 ÁRVORE BINÁRIA

### ArvoreBinaria<T>
```java
// Genérica, tipagem segura
ArvoreBinaria<Encomenda> arvore = new ArvoreBinaria<>();

// Inserção (chaves únicas)
arvore.inserir(
    encomenda,
    Comparator.comparing(Encomenda::getCodigo)
);

// Busca por predicado
Encomenda enc = arvore.buscar(e -> e.getCodigo().equals("ENC001"));

// Busca por intervalos
List<Encomenda> filtradas = arvore.filtrar(
    e -> e.getMassa() > 10.0
);

// Remoção
boolean removido = arvore.remover(
    e -> e.getCodigo().equals("ENC001"),
    Comparator.comparing(Encomenda::getCodigo)
);

// Listagem ordenada (em-ordem)
List<Encomenda> ordenadas = arvore.emOrdem();

// Informações
int tamanho = arvore.getTamanho();
boolean vazia = arvore.estaVazia();
```

---

## 🎨 PAINÉIS UI

### PainelBase (Classe Base Abstrata)
```java
// Todas as subclasses estendem isto:
// PainelDashboard, PainelEncomendas, PainelClientes,
// PainelMovimentacoes, PainelRelatorios

// Métodos auxiliares disponíveis em todas:
protected JPanel criarHeaderPadrao(String titulo);
protected JPanel criarPainelAcoes(JButton... botoes);
protected void estilizarTabela(JTable tabela);
protected JScrollPane criarScrollEstilizado(JComponent comp);

// Template Method - cada painel implementa:
protected abstract void construir();
```

### Exemplo de novo Painel
```java
public class MeuPainel extends PainelBase {
    private JTable tabela;
    
    public MeuPainel(GestorEncomendas gestor) {
        super(gestor);  // Inicializa background, layout, etc
    }
    
    @Override
    protected void construir() {
        // Usar métodos do PainelBase
        JPanel header = criarHeaderPadrao("🔧 Meu Painel");
        JButton btn = new Componentes.BotaoVerde("Ação");
        JPanel acoes = criarPainelAcoes(btn);
        header.add(acoes, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);
        
        tabela = new JTable(...);
        estilizarTabela(tabela);
        JScrollPane scroll = criarScrollEstilizado(tabela);
        add(scroll, BorderLayout.CENTER);
    }
}
```

---

## ⚙️ CONSTANTES DO SISTEMA

### Classe Constantes
```java
// Ficheiro: Constantes.java
// Uso: Constantes.CHAVE

// Arquivo
Constantes.ARQUIVO_DADOS        // "dados.ser"

// Prefixos
Constantes.PREFIXO_CLIENTE       // "CLI"
Constantes.PREFIXO_ENCOMENDA     // "ENC"
Constantes.PREFIXO_MOVIMENTACAO  // "MOV"

// Formato
Constantes.FORMATO_ID            // "%03d"

// Valores padrão
Constantes.QUANTIDADE_MINIMA_PADRAO    // 5
Constantes.TAXA_BASE_KG                // 2.0
Constantes.TAXA_BASE_M3                // 100.0

// Mensagens
Constantes.MSG_ENCOMENDA_DUPLICADA     // "Já existe..."
Constantes.MSG_CLIENTE_DUPLICADO       // "Cliente com..."
// ... mais mensagens ...

// Gerar ID automaticamente
String novoId = Constantes.PREFIXO_CLIENTE + 
                String.format(Constantes.FORMATO_ID, contador++);
// Resultado: "CLI001", "CLI002", ...
```

---

## 🔄 FLUXO DE OPERAÇÕES

### 1. Cadastrar Encomenda
```java
try {
    Encomenda novaEnc = new Encomenda(...);
    novaEnc.setStatus(StatusEncomenda.PENDENTE);
    gestor.cadastrarEncomenda(novaEnc);  // Throws se duplicada
} catch (IllegalArgumentException e) {
    // Mostrar erro: "Já existe encomenda com este código."
}
```

### 2. Registrar Movimentação
```java
try {
    gestor.registrarMovimentacao(
        "ENC001",
        50,
        TipoMovimentacao.ENTRADA,  // ← enum
        "Recebimento"
    );
    // Atualiza quantidade automaticamente
    // Emite alerta se precisar repor
} catch (IllegalArgumentException e) {
    // "Stock insuficiente" ou "Encomenda não encontrada"
}
```

### 3. Listar e Filtrar
```java
// Todas as encomendas (ordenadas por código)
List<Encomenda> todas = gestor.listarEncomendas();

// Apenas as que precisam reposição
List<Encomenda> baixoStock = gestor.getEncomendasStockBaixo();

// Buscar específica
Encomenda encontrada = gestor.buscarEncomendaPorCodigo("ENC001");
if (encontrada != null) {
    // Usar...
}
```

### 4. Editar e Excluir
```java
// Editar
Encomenda existente = gestor.buscarEncomendaPorCodigo("ENC001");
existente.setStatus(StatusEncomenda.ENTREGUE);
gestor.editarEncomenda(existente);

// Excluir
try {
    gestor.excluirEncomenda("ENC001");
} catch (IllegalArgumentException e) {
    // "Encomenda não encontrada."
}
```

### 5. Persistência
```java
// Salvar automaticamente ao fechar (implementado em JanelaPrincipal)
gestor.salvarDados();  // Escreve em dados.ser

// Carregar automaticamente ao iniciar
gestor.carregarDados();  // Lê de dados.ser
```

---

## ✅ CHECKLIST DE VALIDAÇÕES

Todas as validações ocorrem **automaticamente**:

```
Encomenda:
  ✅ Código não vazio
  ✅ Descrição não vazia
  ✅ Prazo > 0
  ✅ Massa > 0
  ✅ Volume > 0
  ✅ LocalOrigem não vazio
  ✅ LocalDestino não vazio

Cliente:
  ✅ ID não vazio
  ✅ Nome não vazio
  ✅ Contacto não vazio
  ✅ Endereço não vazio
  ✅ Email válido (regex)

Movimentacao:
  ✅ ID não vazio
  ✅ Encomenda não nula
  ✅ Tipo não nulo
  ✅ Quantidade > 0
  ✅ Data não nula

GestorEncomendas:
  ✅ Evita duplicação de códigos
  ✅ Evita duplicação de IDs
  ✅ Impede venda com stock insuficiente
  ✅ Atualiza automaticamente quantidades
  ✅ Emite alerta de reposição
```

---

## 🚀 PRÓXIMOS PASSOS RECOMENDADOS

1. **Testar Compilação:**
   ```bash
   javac -d bin src/c/*.java
   java -cp bin c.LoginFrame
   ```

2. **Testes Unitários:**
   ```java
   // Considere adicionar testes para:
   // - Validações de Encomenda
   // - Validações de Cliente
   // - ArvoreBinaria (inserção, busca, remoção)
   ```

3. **Melhorias Futuras:**
   - [ ] Banco de dados (PostgreSQL/MySQL)
   - [ ] Logging (Log4j2)
   - [ ] Testes automatizados (JUnit 5)
   - [ ] Relatórios em PDF
   - [ ] Interface REST API
   - [ ] Autenticação melhorada

---

**Versão:** 2.0  
**Data:** 28 de Maio de 2026  
**Autor:** Sistema Fikissa  
**Status:** ✅ Pronto para uso
